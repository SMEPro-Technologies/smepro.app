# SMEPro Repository Structure

This document outlines the repository structure for the SMEPro application using a Mermaid diagram. It includes source code, public assets, and deployment/configuration files.

```mermaid
graph TD
    subgraph Legend
        direction LR
        folder[fa:fa-folder Folder]
        file[fa:fa-file File]
    end

    A[SMEPro Repo] --> H[README.md];
    A --> I[.gitignore];
    A --> M[Dockerfile];
    A --> N[package.json];
    A --> O[repo_structure.md];
    A --> K[tsconfig.json];
    A --> L[tsconfig.node.json];
    A --> J[vite.config.ts];
    A --> D[index.html];
    A --> E[metadata.json];
    
    A --> B[public];
    B --> B1[schemas];
    B1 --> B1a[business_categories.json];
    B1 --> B1b[solo_categories.json];
    B1 --> B1c[vault_categories.json];

    A --> C[src];
    C --> C1[components];
    C --> C2[services];
    C --> C3[App.tsx];
    C --> C4[index.tsx];
    C --> C5[types.ts];
    C --> C6[constants.ts];
    
    A --> F[scripts];
    F --> F1[deploy.sh];
    F --> F2[init_db.sql];
    
    A --> G[config];
    G --> G1[nginx.conf];

    subgraph src/components
        C1 --> C1a[admin];
        C1a --> C1a1[AdminDashboard.tsx];
        C1a --> C1a2[AdminLoginPage.tsx];

        C1 --> C1b[modals];
        C1b --> C1b1[Modal.tsx];
        C1b --> C1b2[...];

        C1 --> C1c[ChatWindow.tsx];
        C1 --> C1d[Vault.tsx];
        C1 --> C1e[...];
    end

    subgraph src/services
        C2 --> C2a[geminiService.ts];
        C2 --> C2b[backend.ts];
        C2 --> C2c[collaborationService.ts];
        C2 --> C2d[configService.ts];
    end
```

import { SubscriptionPlan } from '../types';

const smeConfigCache: { [key: string]: any } = {};
let vaultCategoriesCache: string[] | null = null;

export const configService = {
  fetchSmeConfigSchema: async (plan: SubscriptionPlan): Promise<any> => {
    const fileName = plan.startsWith('solo') ? 'solo_categories.json' : 'business_categories.json';
    if (smeConfigCache[fileName]) {
      return smeConfigCache[fileName];
    }
    try {
      const response = await fetch(`/schemas/${fileName}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch ${fileName}`);
      }
      const schema = await response.json();
      smeConfigCache[fileName] = schema;
      return schema;
    } catch (error) {
      console.error("Error fetching SME config schema:", error);
      return null;
    }
  },

  fetchVaultCategories: async (): Promise<string[]> => {
    if (vaultCategoriesCache) {
      return vaultCategoriesCache;
    }
    try {
        const response = await fetch('/schemas/vault_categories.json');
        if (!response.ok) {
            throw new Error('Failed to fetch vault_categories.json');
        }
        const data = await response.json();
        const categories = data.properties.categories.items.enum;
        vaultCategoriesCache = categories;
        return categories;
    } catch (error) {
        console.error("Error fetching default vault categories:", error);
        return ['General', 'Strategy', 'Action Items']; // Fallback
    }
  },
};
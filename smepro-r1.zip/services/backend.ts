import { UserProfile, VaultItem, SubscriptionPlan, Quota } from '../types';
import { configService } from './configService';

const USER_PROFILE_KEY = 'smeProUserProfile';
const VAULT_ITEMS_KEY = 'smeProVaultItems';
const VAULT_CATEGORIES_KEY = 'smeProVaultCategories';

const BASE_QUOTAS: Record<SubscriptionPlan, UserProfile['quotas']> = {
    'solo': {
        vaultStorage: { limit: 1, used: Math.random() * 0.2 },
        analyzerActions: { limit: 50, used: Math.floor(Math.random() * 10) },
        aiBandwidth: { limit: 1000, used: Math.floor(Math.random() * 200) }
    },
    'solo-plus': {
        vaultStorage: { limit: 5, used: Math.random() * 1 },
        analyzerActions: { limit: 150, used: Math.floor(Math.random() * 30) },
        aiBandwidth: { limit: 5000, used: Math.floor(Math.random() * 1000) }
    },
    'business': {
        vaultStorage: { limit: 10, used: Math.random() * 2 },
        analyzerActions: { limit: 250, used: Math.floor(Math.random() * 50) },
        aiBandwidth: { limit: 10000, used: Math.floor(Math.random() * 2000) }
    },
    'pro-plus': {
        vaultStorage: { limit: 50, used: Math.random() * 10 },
        analyzerActions: { limit: 500, used: Math.floor(Math.random() * 100) },
        aiBandwidth: { limit: 50000, used: Math.floor(Math.random() * 10000) }
    },
    'super-plus': {
        vaultStorage: { limit: 200, used: Math.random() * 40 },
        analyzerActions: { limit: 10000, used: Math.floor(Math.random() * 2000) },
        aiBandwidth: { limit: 200000, used: Math.floor(Math.random() * 40000) }
    }
};

// Mock backend service that uses localStorage
export const backend = {
  fetchUserProfile: async (): Promise<UserProfile | null> => {
    const profileJson = localStorage.getItem(USER_PROFILE_KEY);
    return profileJson ? JSON.parse(profileJson) : null;
  },

  saveUserProfile: async (profileData: Omit<UserProfile, 'quotas'> | UserProfile): Promise<UserProfile> => {
    let finalProfile: UserProfile;
    // Check if it's a full profile update or a new profile creation
    if ('quotas' in profileData && profileData.quotas) {
        finalProfile = profileData as UserProfile;
    } else {
        // It's a new profile, add default quotas
        finalProfile = {
            ...(profileData as Omit<UserProfile, 'quotas'>),
            quotas: BASE_QUOTAS[profileData.accountType]
        };
    }
    localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(finalProfile));
    return finalProfile;
  },
  
  fetchVaultItems: async (): Promise<VaultItem[]> => {
    const itemsJson = localStorage.getItem(VAULT_ITEMS_KEY);
    return itemsJson ? JSON.parse(itemsJson) : [];
  },

  saveVaultItem: async (item: VaultItem): Promise<VaultItem> => {
    let items = await backend.fetchVaultItems();
    const existingIndex = items.findIndex((i: VaultItem) => i.id === item.id);
    if (existingIndex > -1) {
      items[existingIndex] = item;
    } else {
      items.push(item);
    }
    localStorage.setItem(VAULT_ITEMS_KEY, JSON.stringify(items));
    return item;
  },

  deleteVaultItem: async (itemId: string): Promise<void> => {
    let items = await backend.fetchVaultItems();
    items = items.filter((i: VaultItem) => i.id !== itemId);
    localStorage.setItem(VAULT_ITEMS_KEY, JSON.stringify(items));
  },
  
  fetchCategories: async (): Promise<string[]> => {
    const catsJson = localStorage.getItem(VAULT_CATEGORIES_KEY);
    if (catsJson) {
        return JSON.parse(catsJson);
    }
    // If no categories in local storage, fetch defaults from config
    let categories = await configService.fetchVaultCategories();
    // Ensure "Subject Matter" exists for the new feature
    if (!categories.includes("Subject Matter")) {
        categories.push("Subject Matter");
    }
    return categories;
  },
  
  saveCategories: async (categories: string[]): Promise<string[]> => {
    localStorage.setItem(VAULT_CATEGORIES_KEY, JSON.stringify(categories));
    return categories;
  }
};
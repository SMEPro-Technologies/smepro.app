

import { GoogleGenAI, Type } from "@google/genai";
import { ChatMessage, SmeConfig, VaultItem, SubscriptionPlan, SuggestedSme, WorkshopData, AiPlatform } from '../types';
import { configService } from './configService';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    console.warn("API_KEY environment variable not set. Using a placeholder. AI features will be mocked.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || 'placeholder' });

const buildSystemPrompt = (smeConfigs: SmeConfig[], accountType: SubscriptionPlan, isWorkshop: boolean = false): string => {
    const isBusinessPlan = accountType === 'business' || accountType === 'pro-plus' || accountType === 'super-plus';

    const getSmeDescription = (smeConfig: SmeConfig, isBusiness: boolean) => {
        if (isBusiness) {
            return `- Industry Focus: **${smeConfig.industry}**, Sub-Type: **${smeConfig.subType}**, Operating Segment: **${smeConfig.segment}**`;
        }
        return `- Field: **${smeConfig.industry}**, Discipline: **${smeConfig.subType}**, Objective: **${smeConfig.segment}**`;
    };
    
    let coreMission = `You are a world-class Subject Matter Expert (SME) named SMEPro. Your mission is to provide precise, actionable, and insightful advice. Format responses using clear markdown.`;

    let collaborationRule = '';
    if (smeConfigs.length > 1) {
        if (isWorkshop) {
            collaborationRule = `You are acting as a facilitator for a workshop. Synthesize the perspectives of the experts on your team and present a unified response in the third person. Clearly attribute insights to the relevant expert. For example: "The Sales & Marketing expert suggests..."`;
        } else {
            collaborationRule = `You are operating as a collaborative team of experts providing a unified response. Draw on the collective expertise of the team.`;
        }
    }
        
    const specializationHeader = smeConfigs.length > 1 ? `Your current specializations are:` : `Your current specialization is:`;
    const smeDetails = smeConfigs.map(sme => getSmeDescription(sme, isBusinessPlan)).join('\n');
    
    const criticalRule = `**CRITICAL RULE - YOUR PRIMARY DIRECTIVE:** Your absolute highest priority is to operate strictly within your designated specialization. If a user's request falls outside your area of expertise, you MUST NOT attempt to answer it. Instead, you MUST immediately pivot. Your response MUST begin by:
1.  Clearly stating the limits of your current expertise (e.g., "As the specialist in [Your Expertise], I cannot provide an analysis on [User's Topic].").
2.  Explicitly recommending a different, more appropriate SME segment to handle the request.
3.  Briefly explaining why that SME is a better fit.
For example: "As the specialist in Engineering & Design, I cannot provide a detailed marketing strategy. To properly address this, I strongly recommend adding an expert from the 'Sales & Marketing' segment to this session. They will have the right expertise for this task."
This is not a suggestion; it is your core function for maintaining user trust and providing accurate, safe intelligence. Failure to adhere to this rule is a critical failure of your function.`;

    return `${coreMission} ${collaborationRule}\n\n${specializationHeader}\n${smeDetails}\n\n${criticalRule}\n\nIf the user provides a [RESPONSE STYLE: ...] prefix in their prompt, you must adhere to that format for your response.`;
};


export const geminiService = {
  generateChatResponse: async (history: ChatMessage[], smeConfigs: SmeConfig[], accountType: SubscriptionPlan): Promise<string> => {
    if (!API_KEY || API_KEY === 'placeholder') {
        console.warn("Using placeholder API key. AI response is mocked.");
        const primarySme = smeConfigs[0];
        return new Promise(resolve => setTimeout(() => resolve(`This is a mock response because no API key is set. As an expert in **${primarySme.segment}**, I would normally provide a detailed answer here about: *${history[history.length - 1].content}*`), 1000));
    }

    try {
        const isWorkshopMode = history.some(m => m.role === 'system' && m.content.includes('WORKSHOP MODE ACTIVATED'));
        const contents = history
            .filter(m => m.role !== 'system')
            .map(m => ({
                role: m.role as 'user' | 'model',
                parts: [{ text: m.content }]
            }));

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                systemInstruction: buildSystemPrompt(smeConfigs, accountType, isWorkshopMode),
            }
        });

        return response.text;
    } catch (error) {
      console.error("Error generating response from Gemini API:", error);
      return "I'm sorry, but I encountered an error while processing your request. Please check the console for details and ensure your API key is configured correctly.";
    }
  },

  analyzeVaultItems: async (items: VaultItem[], promptTemplate: string, responseFormat: string): Promise<string> => {
    if (!API_KEY || API_KEY === 'placeholder') {
        console.warn("Using placeholder API key. Analysis response is mocked.");
        return new Promise(resolve => setTimeout(() => resolve(`This is a mock analysis. I would normally synthesize these items into a cohesive **${responseFormat}** based on your request to **${promptTemplate}**`), 1000));
    }
    try {
      const prompt = `As a strategic analyst, your task is to analyze the following knowledge items from a user's vault.
Objective: ${promptTemplate}.
Required Output Format: You must structure your response as a "${responseFormat}".

Here are the vault items:
${items.map(item => `---
### ${item.title} (Category: ${item.category})
${item.content}
---`).join('\n\n')}

Analyze this information now, adhering strictly to the objective and output format.
`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
      });
      
      return response.text;
    } catch (error) {
      console.error("Error analyzing vault items with Gemini API:", error);
      return "I'm sorry, but I encountered an error during the analysis. Please try again later.";
    }
  },

  suggestRelatedSmes: async (currentConfigs: SmeConfig[], history: ChatMessage[]): Promise<SuggestedSme[]> => {
    if (currentConfigs.length === 0 || history.length < 2) {
        return [];
    }
    if (!API_KEY || API_KEY === 'placeholder') {
        return []; 
    }
    
    try {
        const schema = await configService.fetchSmeConfigSchema('business');
        if (!schema?.properties?.operatingSegment?.enum) {
            console.error("Could not fetch or parse operating segments from schema.");
            return [];
        }
        const allSegments = schema.properties.operatingSegment.enum as string[];
        const activeSegments = currentConfigs.map(c => c.segment);
        const availableSegments = allSegments.filter(s => !activeSegments.includes(s));
        
        if (availableSegments.length === 0) return [];

        const conversationContext = history.slice(-5).map(m => `${m.role}: ${m.content}`).join('\n');

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Based on the following conversation context, identify up to 3 relevant 'operating segments' that could provide valuable expertise.
            
Current Experts: ${activeSegments.join(', ')}
            
Conversation:
${conversationContext}
            
Respond ONLY with a JSON object that matches the specified schema.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        suggestions: {
                            type: Type.ARRAY,
                            description: "A list of 2-3 recommended SME segments.",
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    segment: {
                                        type: Type.STRING,
                                        enum: availableSegments,
                                        description: "The recommended SME operating segment."
                                    },
                                    reason: {
                                        type: Type.STRING,
                                        description: "A brief justification for why this SME is recommended based on the conversation."
                                    }
                                },
                                required: ['segment', 'reason']
                            }
                        }
                    },
                    required: ['suggestions']
                }
            }
        });

        const parsedJson = JSON.parse(response.text);
        
        if (!parsedJson.suggestions) return [];

        const suggestedSmes: SuggestedSme[] = parsedJson.suggestions.map((s: any) => ({
            config: {
                industry: currentConfigs[0].industry,
                subType: currentConfigs[0].subType,
                segment: s.segment,
            },
            reason: s.reason,
        }));
        
        return suggestedSmes;

    } catch (error) {
        console.error("Error getting dynamic SME suggestions:", error);
        return [];
    }
  },

  generateSmeIntroduction: async (newSme: SmeConfig, history: ChatMessage[]): Promise<string> => {
    if (!API_KEY || API_KEY === 'placeholder') {
        return Promise.resolve(`Hello, I am the new SME specializing in **${newSme.segment}**. I have reviewed the conversation and am ready to assist.`);
    }

    try {
        const prompt = `You are a new Subject Matter Expert joining an ongoing conversation. Your specialization is: Industry: ${newSme.industry}, Sub-Type: ${newSme.subType}, Segment: ${newSme.segment}.
Based on the last few messages of the conversation provided below, generate a brief, professional, and context-aware introductory message (2-3 sentences).
Your introduction should acknowledge the current topic and state how you can contribute. Start with "Hello, I've joined the session."

CONVERSATION HISTORY:
${history.slice(-4).map(m => `${m.senderName || m.role}: ${m.content}`).join('\n')}

Generate the introductory message now:`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Error generating SME introduction:", error);
        return `Hello, I've joined the session as an expert in ${newSme.segment}. I'm ready to contribute.`;
    }
  },

  getDeeperInsight: async (selectedText: string, fullContext: string): Promise<string> => {
    if (!API_KEY || API_KEY === 'placeholder') {
        return Promise.resolve(`This is a mock insight. I would normally elaborate on **${selectedText}** based on the provided context.`);
    }

    try {
        const prompt = `A user has requested a deeper insight on the term "${selectedText}".
Based on the full context of the message below, please provide a concise and clear elaboration on this specific term.
Explain what it is, why it's relevant to the conversation, and any important nuances.

FULL MESSAGE CONTEXT:
---
${fullContext}
---

Provide the deeper insight on "${selectedText}" now:`;
        
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });

        return response.text;
    } catch (error) {
        console.error("Error generating deeper insight:", error);
        return `I am unable to provide further insight on "${selectedText}" at this moment.`;
    }
  },

  getWorkshopGuidanceAndSmes: async (workshopData: Pick<WorkshopData, 'objective' | 'backstory'>, primarySmeConfig: SmeConfig): Promise<{ guidance: string; smes: SuggestedSme[] }> => {
    if (!API_KEY || API_KEY === 'placeholder' || (!workshopData.objective && !workshopData.backstory)) {
        return { guidance: "Start typing your objective or backstory to get AI-powered suggestions.", smes: [] };
    }
    
    try {
        const schema = await configService.fetchSmeConfigSchema('business');
        const allSegments = schema.properties.operatingSegment.enum as string[];

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `As an expert facilitator, analyze the following workshop plan. Provide (1) concise, actionable guidance to improve its focus and clarity, and (2) recommend 2-3 additional SME 'operating segments' that would be valuable participants.
            
Workshop Objective: "${workshopData.objective}"
Workshop Backstory: "${workshopData.backstory}"

Respond ONLY with a JSON object that matches the specified schema.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        guidance: {
                            type: Type.STRING,
                            description: "Actionable, constructive feedback on how to improve the workshop objective and backstory."
                        },
                        smes: {
                            type: Type.ARRAY,
                            description: "A list of 2-3 recommended SME segments based on the workshop context.",
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    segment: {
                                        type: Type.STRING,
                                        enum: allSegments,
                                        description: "The recommended SME operating segment."
                                    },
                                    reason: {
                                        type: Type.STRING,
                                        description: "A brief justification for why this SME is recommended."
                                    }
                                },
                                required: ['segment', 'reason']
                            }
                        }
                    },
                    required: ['guidance', 'smes']
                }
            }
        });

        const parsedJson = JSON.parse(response.text);

        const suggestedSmes: SuggestedSme[] = parsedJson.smes.map((sme: any) => ({
            config: {
                industry: primarySmeConfig.industry,
                subType: primarySmeConfig.subType,
                segment: sme.segment,
            },
            reason: sme.reason,
        }));
        
        return {
            guidance: parsedJson.guidance,
            smes: suggestedSmes,
        };

    } catch (error) {
        console.error("Error getting workshop guidance:", error);
        return { guidance: "An error occurred while getting AI suggestions. Please try again.", smes: [] };
    }
  },

  generateCompetitiveAnalysis: async (competitors: AiPlatform[]): Promise<string> => {
    if (!API_KEY || API_KEY === 'placeholder') {
      return Promise.resolve("This is a mock competitive analysis. In a real scenario, I would compare SMEPro against the selected platforms.");
    }
    try {
      const prompt = `
        As an unbiased AI market analyst, create a detailed competitive analysis.
        Compare the following AI platforms against SMEPro.

        **SMEPro's Core Value Proposition:**
        SMEPro is not just a single AI, but a "Collaborative AI Operating System." Its strength lies in its "Yellow Brick Road" logic, which means it provides a structured, multi-expert (SME) workflow. Users select specialized AIs, collaborate with them in focused "Workshop" sessions, and use an integrated suite of tools (Vault, Analyzer, Builder, Workbench) to turn conversations into tangible, actionable outcomes. Its key differentiator is moving beyond simple Q&A to a goal-oriented, collaborative creation process.

        **Competitors to Analyze:**
        ${competitors.map(c => `- **${c.name}:** Their claim to fame is "${c.claimToFame}".`).join('\n')}

        **Your Task:**
        Provide a side-by-side comparison in a markdown table. Columns should be: "Platform", "Primary Use Case", "Key Strength", and "How SMEPro Differs".
        After the table, write a "Key Takeaways" summary. This summary should highlight where each platform excels and for which type of user or task SMEPro would be the superior choice, emphasizing its unique collaborative and workflow-oriented approach. Maintain an unbiased, professional tone.
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: prompt,
      });

      return response.text;
    } catch (error) {
      console.error("Error generating competitive analysis:", error);
      return "I'm sorry, but I encountered an error while generating the analysis. Please try again.";
    }
  },
};
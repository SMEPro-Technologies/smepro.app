import React, { useState, useEffect, useMemo, useRef } from 'react';
import { UserProfile, VaultItem } from '../types';
import { backend } from '../services/backend';
import { geminiService } from '../services/geminiService';
import { generateId } from '../constants';
import { VaultIcon, CloseIcon, PlusIcon, SearchIcon, AnalyzeIcon, LoadingIcon, DeleteIcon, SMEBuilderIcon, HighlightIcon, LightbulbIcon } from './icons';

interface VaultProps {
  userProfile: UserProfile;
  onClose: () => void;
  onManageCategories: () => void;
  onSaveText: (text: string) => void;
  onContinueInBuilder: (analysisContent: string) => void;
}

const analysisPrompts = [
    "Synthesize these items into a cohesive strategy.",
    "Identify key themes, potential synergies, and actionable strategies.",
    "Create a concise, executive-level summary and a bulleted list of recommendations.",
    "Find contradictions or gaps in the provided information.",
    "Outline a project plan based on these items."
];

const responseTypes = [
    "Expert Analysis",
    "Solution to a Problem",
    "Step by Step Plan",
    "Cited Response",
    "Vault View Summary"
];

const AnalysisToolbar: React.FC<{ 
    top: number; 
    left: number; 
    onHighlight: () => void;
    onGetInsight: () => void;
    onSaveToVault: () => void;
}> = ({ top, left, onHighlight, onGetInsight, onSaveToVault }) => (
    <div className="absolute z-10 flex items-center space-x-1 bg-slate-900 border border-slate-700 rounded-lg p-1 shadow-lg text-sm text-slate-300" style={{ top, left, transform: 'translateX(-50%)' }}>
        <button onClick={onHighlight} title="Highlight & Collect" className="flex items-center space-x-1.5 p-1.5 rounded hover:bg-slate-800">
            <HighlightIcon className="w-4 h-4 text-yellow-300"/>
            <span>Collect</span>
        </button>
        <div className="w-px h-5 bg-slate-700"></div>
        <button onClick={onGetInsight} title="Get Deeper Insight" className="flex items-center space-x-1.5 p-1.5 rounded hover:bg-slate-800">
            <LightbulbIcon className="w-4 h-4 text-cyan-300"/>
            <span>Insight</span>
        </button>
         <div className="w-px h-5 bg-slate-700"></div>
        <button onClick={onSaveToVault} title="Save Snippet to Vault" className="flex items-center space-x-1.5 p-1.5 rounded hover:bg-slate-800">
            <VaultIcon className="w-4 h-4"/>
            <span>Save</span>
        </button>
    </div>
);


const Vault: React.FC<VaultProps> = ({ userProfile, onClose, onManageCategories, onSaveText, onContinueInBuilder }) => {
  const [items, setItems] = useState<VaultItem[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [analysisResult, setAnalysisResult] = useState<string>('');
  const [analysisHtmlContent, setAnalysisHtmlContent] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [promptTemplate, setPromptTemplate] = useState(analysisPrompts[0]);
  const [responseFormat, setResponseFormat] = useState(responseTypes[0]);
  const [showBuilderPrompt, setShowBuilderPrompt] = useState(false);
  const [analysisSelectionToolbar, setAnalysisSelectionToolbar] = useState<{ top: number; left: number; text: string } | null>(null);
  const [subjectMatterSnippets, setSubjectMatterSnippets] = useState<string[]>([]);
  
  const analysisContentRef = useRef<HTMLDivElement>(null);
  const vaultContentRef = useRef<HTMLDivElement>(null);


  useEffect(() => {
    const loadVault = async () => {
      const [vaultItems, vaultCategories] = await Promise.all([
        backend.fetchVaultItems(),
        backend.fetchCategories()
      ]);
      setItems(vaultItems);
      setCategories(vaultCategories);
    };
    loadVault();
  }, []);
  
  // Close popover on outside click
  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (vaultContentRef.current && !vaultContentRef.current.contains(event.target as Node)) {
              setAnalysisSelectionToolbar(null);
          }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredItems = useMemo(() => {
    return items.filter(item => {
      const inCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const inSearch = searchTerm === '' || 
        item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.content.toLowerCase().includes(searchTerm.toLowerCase());
      return inCategory && inSearch;
    });
  }, [items, selectedCategory, searchTerm]);

  const handleSelectItem = (itemId: string) => {
    const newSelection = new Set(selectedItems);
    if (newSelection.has(itemId)) {
      newSelection.delete(itemId);
    } else {
      newSelection.add(itemId);
    }
    setSelectedItems(newSelection);
    setShowBuilderPrompt(false);
  };
  
  const handleAnalyze = async () => {
      if(selectedItems.size < 2) {
          alert("Please select at least 2 items to analyze.");
          return;
      }
      setIsAnalyzing(true);
      setAnalysisResult('');
      setAnalysisHtmlContent('');
      setSubjectMatterSnippets([]);
      setShowBuilderPrompt(false);
      setAnalysisSelectionToolbar(null);
      
      const itemsToAnalyze = items.filter(item => selectedItems.has(item.id));
      const result = await geminiService.analyzeVaultItems(itemsToAnalyze, promptTemplate, responseFormat);
      
      setAnalysisResult(result);
      setAnalysisHtmlContent(window.marked.parse(result));
      setIsAnalyzing(false);
      setShowBuilderPrompt(true);
  };
  
  const handleMouseUp = () => {
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed && selection.toString().trim() !== '') {
          const range = selection.getRangeAt(0);
          if (analysisContentRef.current?.contains(range.commonAncestorContainer)) {
              const rect = range.getBoundingClientRect();
              setAnalysisSelectionToolbar({
                  top: rect.top + window.scrollY - 55,
                  left: rect.left + window.scrollX + rect.width / 2,
                  text: selection.toString(),
              });
          }
      } else {
          setAnalysisSelectionToolbar(null);
      }
  };
  
  const handleHighlightAndCollect = () => {
    const selection = window.getSelection();
    if (selection && !selection.isCollapsed) {
        const selectedText = selection.toString();
        setSubjectMatterSnippets(prev => [...prev, selectedText]);

        const range = selection.getRangeAt(0);
        const marker = document.createElement('mark');
        marker.className = "bg-yellow-400/40 p-0 rounded";
        
        try {
            range.surroundContents(marker);
            if (analysisContentRef.current) {
                setAnalysisHtmlContent(analysisContentRef.current.innerHTML);
            }
        } catch (e) {
            console.error("Highlighting failed:", e);
        }
        
        selection.removeAllRanges();
    }
    setAnalysisSelectionToolbar(null);
  };

  const handleGetDeeperInsight = async (selectedText: string) => {
    setAnalysisSelectionToolbar(null);
    setIsAnalyzing(true);
    const insight = await geminiService.getDeeperInsight(selectedText, analysisResult);
    const newContent = `${analysisResult}\n\n---\n\n**Deeper Insight on "${selectedText}":**\n\n${insight}`;
    setAnalysisResult(newContent);
    setAnalysisHtmlContent(window.marked.parse(newContent));
    setIsAnalyzing(false);
  };

  const handleSaveSelectionToVault = (selectedText: string) => {
    onSaveText(selectedText);
    setAnalysisSelectionToolbar(null);
  };


  const handleSaveSubjectMatter = async () => {
    if (subjectMatterSnippets.length === 0) {
        alert("No subject matter collected.");
        return;
    }

    const title = `Subject Matter from Analysis - ${new Date().toLocaleDateString()}`;
    const content = subjectMatterSnippets.map(snippet => `- ${snippet}`).join('\n\n');

    const newItem: VaultItem = {
        id: generateId(),
        title,
        content,
        category: "Subject Matter",
        tags: ["analysis-collection"],
        createdAt: new Date().toISOString(),
    };

    await backend.saveVaultItem(newItem);
    alert("Subject Matter collection saved to Vault!");
    setSubjectMatterSnippets([]);
  };

  const handleGoToBuilder = () => {
    if (analysisResult) {
      onContinueInBuilder(analysisResult);
    }
  };

  const Select: React.FC<{label: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, options: string[]}> = ({label, value, onChange, options}) => (
    <div>
        <label className="block text-sm font-medium text-slate-400 mb-1">{label}</label>
        <select
          value={value}
          onChange={onChange}
          className="w-full p-2 bg-slate-700 border border-slate-600 rounded-lg text-white focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
        >
          {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    </div>
  );


  return (
    <div ref={vaultContentRef} className="flex flex-col h-full bg-slate-900 text-slate-300 animate-fade-in">
      <header className="flex-shrink-0 p-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
        <div className="flex items-center space-x-3">
          <VaultIcon className="w-6 h-6 text-cyan-400" />
          <h2 className="text-xl font-bold text-white">SMEPro Vault</h2>
        </div>
        <button onClick={onClose} className="p-2 rounded-full hover:bg-slate-700">
          <CloseIcon className="w-6 h-6" />
        </button>
      </header>
      
      <div className="flex-grow flex flex-col md:flex-row overflow-hidden">
        {/* Items List */}
        <div className="w-full md:w-1/2 flex flex-col border-r border-slate-700">
          <div className="p-4 border-b border-slate-700 space-y-4">
            <div className="relative">
              <SearchIcon className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input type="text" placeholder="Search vault..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-slate-700 rounded-lg pl-10 pr-4 py-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
            </div>
            <div className="flex items-center space-x-2 overflow-x-auto pb-2">
              <button onClick={() => setSelectedCategory('All')} className={`px-3 py-1 text-sm rounded-full whitespace-nowrap ${selectedCategory === 'All' ? 'bg-cyan-500 text-white' : 'bg-slate-700 hover:bg-slate-600'}`}>All</button>
              {categories.map(cat => (
                <button key={cat} onClick={() => setSelectedCategory(cat)} className={`px-3 py-1 text-sm rounded-full whitespace-nowrap ${selectedCategory === cat ? 'bg-cyan-500 text-white' : 'bg-slate-700 hover:bg-slate-600'}`}>{cat}</button>
              ))}
               <button onClick={onManageCategories} className="p-1.5 rounded-full bg-slate-700 hover:bg-slate-600"><PlusIcon className="w-4 h-4"/></button>
            </div>
          </div>
          <div className="flex-grow overflow-y-auto p-2">
            {filteredItems.map(item => (
              <div key={item.id} onClick={() => handleSelectItem(item.id)} className={`p-3 mb-2 rounded-lg cursor-pointer transition-colors border ${selectedItems.has(item.id) ? 'bg-cyan-500/10 border-cyan-500' : 'bg-slate-800 border-slate-700 hover:bg-slate-700'}`}>
                <h4 className="font-bold text-white truncate">{item.title}</h4>
                <p className="text-sm text-slate-400 truncate mt-1">{item.content}</p>
                <div className="text-xs text-slate-500 mt-2">{item.category}</div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Analysis Workbench */}
        <div className="w-full md:w-1/2 flex flex-col">
          <div className="p-4 border-b border-slate-700 space-y-4">
             <h3 className="text-lg font-bold text-white">Analysis Workbench</h3>
             <Select label="System Prompt" value={promptTemplate} onChange={e => setPromptTemplate(e.target.value)} options={analysisPrompts} />
             <Select label="Response Type" value={responseFormat} onChange={e => setResponseFormat(e.target.value)} options={responseTypes} />
          </div>
          <div className="flex-grow overflow-y-auto p-4" onMouseUp={handleMouseUp}>
            {isAnalyzing && <div className="flex justify-center items-center h-full"><LoadingIcon className="w-8 h-8"/></div>}
            {analysisHtmlContent && <div ref={analysisContentRef} className="prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{__html: analysisHtmlContent}}></div>}
            {!isAnalyzing && !analysisResult && <div className="text-center text-slate-500 py-10">Select 2 or more items and click Analyze.</div>}
            {analysisSelectionToolbar && (
                <AnalysisToolbar 
                    top={analysisSelectionToolbar.top} 
                    left={analysisSelectionToolbar.left} 
                    onHighlight={handleHighlightAndCollect}
                    onGetInsight={() => handleGetDeeperInsight(analysisSelectionToolbar.text)}
                    onSaveToVault={() => handleSaveSelectionToVault(analysisSelectionToolbar.text)}
                />
            )}
          </div>
          {subjectMatterSnippets.length > 0 && (
            <div className="p-4 border-t border-slate-700 bg-slate-800/50">
              <h4 className="text-md font-bold text-white mb-2">Collected Subject Matter ({subjectMatterSnippets.length})</h4>
              <div className="space-y-2 max-h-24 overflow-y-auto pr-2">
                {subjectMatterSnippets.map((snippet, index) => (
                  <p key={index} className="text-sm bg-slate-700 p-2 rounded truncate">"{snippet}"</p>
                ))}
              </div>
              <button onClick={handleSaveSubjectMatter} className="w-full mt-3 py-2 bg-slate-600 hover:bg-slate-500 rounded-md font-semibold text-sm">Save Collection to Vault</button>
            </div>
          )}
          {showBuilderPrompt && !isAnalyzing && (
            <div className="p-4 border-t border-slate-700 bg-slate-800/50">
                <button onClick={handleGoToBuilder} className="w-full flex justify-center items-center space-x-2 py-3 px-4 bg-slate-600 hover:bg-slate-500 text-white font-bold rounded-lg transition-colors">
                    <SMEBuilderIcon className="w-5 h-5"/>
                    <span>Continue in SMEBuilder</span>
                </button>
            </div>
          )}
          <div className="p-4 border-t border-slate-700">
            <button onClick={handleAnalyze} disabled={selectedItems.size < 2 || isAnalyzing} className="w-full flex justify-center items-center space-x-2 py-3 px-4 bg-cyan-500 hover:bg-cyan-600 text-white font-bold rounded-lg transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed">
              <AnalyzeIcon className="w-5 h-5"/>
              <span>Analyze ({selectedItems.size}) Items</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Vault;


import React from 'react';
import { SubscriptionPlan } from '../types';
import { CheckCircleIcon, CloseIcon } from './icons';

// FIX: Removed local type declaration for 'stripe-buy-button' custom element.
// This is now handled globally in types.ts to avoid conflicts.

interface PlanComparisonTableProps {
  billingCycle: 'monthly' | 'annual';
}

type PlanId = 'solo' | 'business' | 'solo-plus' | 'pro-plus' | 'super-plus';

const STRIPE_PUBLISHABLE_KEY = "pk_live_51SRoz7Cr7Y6oWGTOW7LRIrkdqAafL3JR05CSReKRP89TEGDRq4A9gB14fddn21bbizvkDuSoV9hsVpZgTjB2p6my00lrRAeeQd";

const planDetails = {
    plans: [
        { id: 'solo' as PlanId, name: 'Solo', priceMonthly: 20, priceAnnual: 16, isFeatured: false, buyButtonId: 'buy_btn_1SSqesCavz56QskQP4HlMn7Z' },
        { id: 'business' as PlanId, name: 'Business', priceMonthly: 45, priceAnnual: 36, isFeatured: false, buyButtonId: 'buy_btn_1SSqfACavz56QskQvjJg1aF2' },
        { id: 'solo-plus' as PlanId, name: 'Solo+', priceMonthly: 45, priceAnnual: 36, isFeatured: true, buyButtonId: 'buy_btn_1SSqg5Cavz56QskQb1N3cK8d' },
        { id: 'pro-plus' as PlanId, name: 'Pro+', priceMonthly: 85, priceAnnual: 68, isFeatured: false, buyButtonId: 'buy_btn_1SSqh1Cavz56QskQxL5O4pG9' },
        { id: 'super-plus' as PlanId, name: 'Super+', priceMonthly: 0, priceAnnual: 0, isFeatured: false, buyButtonId: null },
    ],
    features: [
        { name: 'AI Quota', values: { solo: '50 tasks/month', business: '250 tasks/month', 'solo-plus': '150 tasks/month', 'pro-plus': '500 tasks/month', 'super-plus': 'Unlimited tiered usage' } },
        { name: 'Vault', values: { solo: '1 GB', business: '10 GB per user', 'solo-plus': '5 GB', 'pro-plus': '50 GB per user', 'super-plus': 'Scalable (TBs)' } },
        { name: 'Analyzer', values: { solo: 'Standard analysis', business: 'Advanced comparative insights', 'solo-plus': 'Analyzer+ (deeper synthesis)', 'pro-plus': 'Multi-document synthesis, scenario modeling', 'super-plus': 'Predictive modeling, domain-specific expertise' } },
        { name: 'Builder', values: { solo: 'Basic content generation', business: 'Expanded creation (apps, workflows, advanced reports)', 'solo-plus': 'Builder+ (multi-section reports, structured tools)', 'pro-plus': 'Full app/extension generation', 'super-plus': 'OEM licensing, custom integrations' } },
        { name: 'Workbench', values: { solo: 'Limited tuning & export', business: 'Full workspace with advanced tuning, multi-format export', 'solo-plus': 'Enhanced tuning, multi-format export', 'pro-plus': 'Enterprise-grade collaborative editing', 'super-plus': 'Fully configurable production workspace' } },
        { name: 'Multi-SME Collaboration', values: { solo: false, business: false, 'solo-plus': 'Context-driven SME expansion', 'pro-plus': 'Context-driven + advanced SME orchestration', 'super-plus': 'Full collaborative SME ecosystem' } },
        { name: 'Workshop Mode', values: { solo: false, business: false, 'solo-plus': 'Basic Workshop setup (agenda, objectives)', 'pro-plus': 'Advanced Workshop mode (multi-SME alignment, off-topic detection)', 'super-plus': 'Enterprise Workshop AI' } },
    ]
};

const FeatureCell: React.FC<{ value: string | boolean }> = ({ value }) => {
    if (typeof value === 'boolean') {
        return value ? <CheckCircleIcon className="w-6 h-6 text-cyan-400 mx-auto" /> : <CloseIcon className="w-6 h-6 text-slate-500 mx-auto" />;
    }
    return <span className="text-slate-300">{value}</span>;
};


const PlanComparisonTable: React.FC<PlanComparisonTableProps> = ({ billingCycle }) => {

    return (
        <div className="w-full">
            <div className="overflow-x-auto">
                <table className="w-full min-w-[1000px] border-collapse text-center">
                    <thead>
                        <tr>
                            <th className="p-4 text-left text-lg font-bold text-white w-[20%]">Feature</th>
                            {planDetails.plans.map(plan => (
                                <th key={plan.id} className={`p-4 border-l border-slate-700 w-[16%] ${plan.isFeatured ? 'bg-slate-800 rounded-t-xl' : ''}`}>
                                    <h3 className={`text-2xl font-bold ${plan.isFeatured ? 'text-cyan-400' : 'text-white'}`}>{plan.name}</h3>
                                    {plan.id !== 'super-plus' && (
                                        <div className="mt-2">
                                            <span className="text-4xl font-extrabold text-white">${billingCycle === 'annual' ? plan.priceAnnual : plan.priceMonthly}</span>
                                            <span className="text-slate-400">/mo</span>
                                        </div>
                                    )}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {planDetails.features.map((feature, index) => (
                            <tr key={feature.name} className="border-t border-slate-700">
                                <td className="p-4 text-left font-semibold text-white">{feature.name}</td>
                                {planDetails.plans.map(plan => (
                                    <td key={plan.id} className={`p-4 border-l border-slate-700 text-sm ${plan.isFeatured ? 'bg-slate-800' : ''}`}>
                                        <FeatureCell value={feature.values[plan.id]} />
                                    </td>
                                ))}
                            </tr>
                        ))}
                        <tr className="border-t border-slate-700">
                            <td className="p-4"></td>
                            {planDetails.plans.map(plan => {
                                return (
                                    <td key={plan.id} className={`p-4 border-l border-slate-700 ${plan.isFeatured ? 'bg-slate-800 rounded-b-xl' : ''}`}>
                                        {plan.id === 'super-plus' ? (
                                             <a href="mailto:sales@smepro.app" className="w-full block py-3 font-semibold rounded-lg transition-colors bg-slate-700 hover:bg-slate-600 text-white">
                                                Contact Sales
                                            </a>
                                        ) : (
                                            // FIX: Changed props to camelCase for React JSX compatibility. React converts camelCase props to kebab-case attributes for custom elements.
                                            <stripe-buy-button
                                                buyButtonId={plan.buyButtonId!}
                                                publishableKey={STRIPE_PUBLISHABLE_KEY}
                                            />
                                        )}
                                    </td>
                                );
                            })}
                        </tr>
                    </tbody>
                </table>
            </div>

            <div className="mt-12 max-w-4xl mx-auto p-6 bg-slate-800/50 rounded-lg border border-slate-700">
                <h3 className="text-2xl font-bold text-white text-center mb-4">🔎 Key Differentiators</h3>
                <ul className="space-y-3 text-slate-400">
                    <li><strong className="text-cyan-400">Solo & Business →</strong> Full access to core features, capped by quota and storage.</li>
                    <li><strong className="text-cyan-400">Solo+ & Pro+ →</strong> Unlock multi-SME collaboration and Workshop Mode, enabling dynamic, collaborative AI sessions.</li>
                    <li><strong className="text-cyan-400">Super+ →</strong> Enterprise-grade, fully configurable collaborative AI ecosystem with predictive modeling, OEM licensing, and autonomous SME orchestration.</li>
                </ul>
            </div>
        </div>
    );
};

export default PlanComparisonTable;
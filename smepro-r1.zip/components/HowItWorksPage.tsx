
import React from 'react';
import { CheckCircleIcon } from './icons';

interface HowItWorksPageProps {
  onGetStarted: () => void;
}

const Step: React.FC<{ number: number; title: string; description: string; }> = ({ number, title, description }) => (
    <div className="flex items-start space-x-4">
        <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-slate-700 text-cyan-400 font-bold text-xl rounded-full border-2 border-slate-600">
            {number}
        </div>
        <div>
            <h3 className="text-xl font-bold text-white">{title}</h3>
            <p className="text-slate-400 mt-1">{description}</p>
        </div>
    </div>
);

const HowItWorksPage: React.FC<HowItWorksPageProps> = ({ onGetStarted }) => {
  return (
    <div className="animate-fade-in container mx-auto px-6 py-16">
        <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold text-white">Simple Steps to Expert Guidance</h1>
            <p className="text-lg text-slate-400 mt-4 max-w-2xl mx-auto">Get from idea to insight in minutes. Here’s how SMEPro Lite streamlines your workflow.</p>
        </div>
        
        <div className="max-w-3xl mx-auto space-y-8">
            <Step number={1} title="Select Your Expert" description="Choose an industry, sub-type, and segment to configure a narrowly-trained AI model for your specific needs." />
            <Step number={2} title="Start the Conversation" description="Engage in a contextual chat session. The AI understands your domain and provides relevant, actionable advice." />
            <Step number={3} title="Save to Your Vault" description="Capture key insights, code snippets, or entire plans in your personal knowledge base with a single click." />
            <Step number={4} title="Analyze & Synthesize" description="Use the AI-powered Analysis Workbench to connect ideas from your Vault and generate novel strategies." />
        </div>

        <div className="text-center mt-16">
            <button
                onClick={onGetStarted}
                className="group inline-flex items-center justify-center bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold py-3 px-8 rounded-full text-lg transition-transform duration-300 hover:scale-105 shadow-lg shadow-cyan-500/20"
                >
                Begin Your First Session
            </button>
        </div>
    </div>
  );
};

export default HowItWorksPage;

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { UserProfile, ChatMessage } from '../types';
import { ModelIcon, UserIcon, VaultIcon, InteractionModeIcon, StepByStepIcon, CopyIcon, CheckIcon } from './icons';
import htmlReactParser, { DOMNode, Element, domToReact } from 'html-react-parser';

declare global {
    interface Window {
        marked: any;
        hljs: any;
    }
}

interface MessageProps {
  message: ChatMessage;
  currentUser: UserProfile;
  onSave: (message: ChatMessage) => void;
  onGetInsight: (selectedText: string, contextMessage: ChatMessage) => void;
  isActionMode: boolean;
}

const CodeBlock: React.FC<{ language: string, children: string }> = ({ language, children }) => {
    const [isCopied, setIsCopied] = useState(false);
    const textToCopy = children;

    const handleCopy = () => {
        navigator.clipboard.writeText(textToCopy).then(() => {
            setIsCopied(true);
            setTimeout(() => setIsCopied(false), 2000);
        });
    };

    return (
        <div className="bg-slate-900 rounded-md my-2 relative group">
            <div className="flex justify-between items-center px-4 py-2 text-xs text-slate-400 border-b border-slate-700">
                <span>{language || 'code'}</span>
                <button onClick={handleCopy} className="flex items-center space-x-1 text-xs">
                    {isCopied ? <CheckIcon className="w-4 h-4 text-green-400" /> : <CopyIcon className="w-4 h-4" />}
                    <span>{isCopied ? 'Copied!' : 'Copy'}</span>
                </button>
            </div>
            <pre className="p-4 overflow-x-auto text-sm"><code className={`language-${language}`} dangerouslySetInnerHTML={{ __html: window.hljs.highlight(textToCopy, { language, ignoreIllegals: true }).value }}></code></pre>
        </div>
    );
};

const InteractiveBoldText: React.FC<{ children: React.ReactNode, onGetInsight: () => void, onSave: () => void }> = ({ children, onGetInsight, onSave }) => {
    const [showPopover, setShowPopover] = useState(false);
    const wrapperRef = useRef<HTMLSpanElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setShowPopover(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handlePopoverClick = (e: React.MouseEvent) => {
        e.stopPropagation(); // prevent message-level click handlers from firing
        setShowPopover(!showPopover);
    };

    return (
        <strong ref={wrapperRef} className="text-cyan-300 font-bold relative cursor-pointer" onClick={handlePopoverClick}>
            {children}
            {showPopover && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-slate-900 border border-slate-700 p-2 rounded-lg shadow-lg z-10 text-white text-sm font-normal">
                    <button onClick={onGetInsight} className="w-full text-left p-2 rounded hover:bg-slate-700">Get Deeper Insight</button>
                    <button onClick={onSave} className="w-full text-left p-2 rounded hover:bg-slate-700">Save to Vault</button>
                </div>
            )}
        </strong>
    );
};

const HighlightToolbar: React.FC<{ top: number, left: number, onHighlight: (color: string) => void }> = ({ top, left, onHighlight }) => {
    const colors = ['bg-cyan-500/30', 'bg-yellow-500/30', 'bg-green-500/30', 'bg-red-500/30'];
    return (
        <div className="absolute z-10 bg-slate-800 border border-slate-700 rounded-lg p-1 flex space-x-1 shadow-lg" style={{ top, left }}>
            {colors.map(color => (
                <button key={color} onClick={() => onHighlight(color)} className={`w-6 h-6 rounded ${color} hover:scale-110 transition-transform`}></button>
            ))}
        </div>
    );
};

const Message: React.FC<MessageProps> = ({ message, currentUser, onSave, onGetInsight, isActionMode }) => {
    const isModel = message.role === 'model';
    const isCurrentUser = message.senderName === currentUser.name;
    const contentRef = useRef<HTMLDivElement>(null);
    
    const [isStepView, setIsStepView] = useState(false);
    
    const [selection, setSelection] = useState<{ top: number, left: number } | null>(null);
    const [contentHtml, setContentHtml] = useState(() => {
        if (message.role === 'system') return `<div class="p-4 bg-slate-800/50 border-l-4 border-cyan-500 text-slate-400 text-sm">${window.marked.parse(message.content)}</div>`;
        return window.marked.parse(message.content, { gfm: true, breaks: true });
    });

    useEffect(() => {
        if (!isActionMode) {
            setIsStepView(false);
        }
    }, [isActionMode]);

    const handleMouseUp = () => {
        if (!isActionMode) return;
        const currentSelection = window.getSelection();
        if (currentSelection && !currentSelection.isCollapsed) {
            const range = currentSelection.getRangeAt(0);
            if (contentRef.current?.contains(range.commonAncestorContainer)) {
                const rect = range.getBoundingClientRect();
                 setSelection({
                    top: rect.top + window.scrollY - 45,
                    left: rect.left + window.scrollX + rect.width / 2 - 50,
                });
            }
        } else {
            setSelection(null);
        }
    };

    const handleHighlight = (color: string) => {
        const currentSelection = window.getSelection();
        if (currentSelection && !currentSelection.isCollapsed) {
            const range = currentSelection.getRangeAt(0);
            const marker = document.createElement('mark');
            marker.className = `p-0 rounded ${color}`;
            try {
                range.surroundContents(marker);
            } catch (e) {
                console.warn("Could not wrap the contents for highlighting:", e);
            }
            currentSelection.removeAllRanges();
            if (contentRef.current) {
                setContentHtml(contentRef.current.innerHTML);
            }
        }
        setSelection(null);
    };

    const parsedContent = useMemo(() => {
        const options = {
            replace: (domNode: DOMNode) => {
                if (domNode instanceof Element && domNode.tagName === 'pre') {
                    const codeNode = domNode.children[0] as Element;
                    if (codeNode && codeNode.tagName === 'code') {
                        const langMatch = codeNode.attribs.class?.match(/language-(.*)/);
                        const language = langMatch ? langMatch[1] : '';
                        const codeContent = (codeNode.children[0] as any)?.data || '';
                        return <CodeBlock language={language}>{codeContent}</CodeBlock>;
                    }
                }
                if (isActionMode && domNode instanceof Element && domNode.tagName === 'strong') {
                    const text = (domNode.children[0] as any)?.data;
                    if (text) {
                        return (
                            <InteractiveBoldText 
                                onGetInsight={() => onGetInsight(text, message)}
                                onSave={() => onSave({ role: 'user', content: `Vault Action Item: ${text}`, timestamp: new Date().toISOString() })}
                            >
                                {domToReact(domNode.children, options)}
                            </InteractiveBoldText>
                        );
                    }
                }
            }
        };
        return htmlReactParser(contentHtml, options);
    }, [isActionMode, contentHtml, onGetInsight, onSave, message]);
    
    const stepByStepItems = useMemo(() => {
        if (!isModel) return [];
        const doc = new DOMParser().parseFromString(contentHtml, 'text/html');
        const listItems = Array.from(doc.querySelectorAll('li')).map(li => li.innerHTML);
        return listItems;
    }, [contentHtml, isModel]);


    if (message.role === 'system') {
        return <div className="py-4 max-w-3xl mx-auto" dangerouslySetInnerHTML={{ __html: contentHtml }}></div>;
    }

    return (
        <div className={`flex items-start space-x-4 py-4 ${isModel ? 'animate-fade-in' : ''}`}>
            <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${isModel ? 'bg-cyan-500' : 'bg-slate-600'}`}>
                {isModel ? <ModelIcon className="w-5 h-5 text-white" /> : <UserIcon className="w-5 h-5 text-white" />}
            </div>
            <div className="flex-grow text-white min-w-0" onMouseUp={handleMouseUp}>
                {isModel && message.senderName && <div className="text-xs font-bold text-cyan-300 mb-1">{message.senderName}</div>}
                {!isModel && !isCurrentUser && <div className="text-xs font-bold text-slate-400 mb-1">{message.senderName}</div>}
                
                {isModel && isStepView && stepByStepItems.length > 0 ? (
                    <div className="space-y-3 mt-2">
                        {stepByStepItems.map((item, index) => (
                            <div key={index} className="flex items-start space-x-3 p-3 bg-slate-800/50 rounded-lg">
                                <div className="flex-shrink-0 w-6 h-6 flex items-center justify-center bg-slate-700 text-cyan-400 font-bold rounded-full">{index + 1}</div>
                                <div className="prose prose-invert prose-sm max-w-none pt-0.5" dangerouslySetInnerHTML={{ __html: item }} />
                            </div>
                        ))}
                    </div>
                ) : (
                    <div ref={contentRef} className="prose prose-invert prose-sm max-w-none" suppressContentEditableWarning={true}>
                         {parsedContent}
                    </div>
                )}
                 {selection && <HighlightToolbar top={selection.top} left={selection.left} onHighlight={handleHighlight} />}
            </div>
            {isModel && (
              <div className="flex flex-col space-y-2 items-center pl-2">
                  <button 
                    onClick={() => onSave(message)}
                    className="p-1.5 rounded-full text-slate-400 hover:text-cyan-400 hover:bg-slate-700 transition-colors"
                    title="Save to Vault"
                  >
                      <VaultIcon className="w-5 h-5"/>
                  </button>
                  {isActionMode && stepByStepItems.length > 0 && (
                     <button 
                        onClick={() => setIsStepView(!isStepView)}
                        className={`p-1.5 rounded-full transition-colors ${isStepView ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-cyan-400 hover:bg-slate-700'}`}
                        title="Toggle Step-by-Step View"
                      >
                          <StepByStepIcon className="w-5 h-5"/>
                      </button>
                  )}
              </div>
            )}
        </div>
    );
};

export default Message;

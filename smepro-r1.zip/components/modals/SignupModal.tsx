
import React, { useState } from 'react';
import Modal from './Modal';
import { SubscriptionPlan } from '../../types';
import { CreditCardIcon } from '../icons';

interface SignupModalProps {
  planInfo: {
    plan: SubscriptionPlan;
    billingCycle: 'monthly' | 'annual';
    price: number;
  };
  onConfirm: (
    signupData: { name: string; email: string; company: string },
    planInfo: { plan: SubscriptionPlan; billingCycle: 'monthly' | 'annual' }
  ) => void;
  onClose: () => void;
}

const SignupModal: React.FC<SignupModalProps> = ({ planInfo, onConfirm, onClose }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [ccNumber, setCcNumber] = useState('');
  const [ccExpiry, setCcExpiry] = useState('');
  const [ccCvc, setCcCvc] = useState('');

  const isSoloPlan = planInfo.plan.startsWith('solo');
  const isFormValid = name.trim() && email.trim() && ccNumber.trim() && ccExpiry.trim() && ccCvc.trim();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormValid) {
      onConfirm(
        { name: name.trim(), email: email.trim(), company: company.trim() || 'N/A' },
        { plan: planInfo.plan, billingCycle: planInfo.billingCycle }
      );
    }
  };

  return (
    <Modal title="Start Your Subscription" onClose={onClose}>
      <form onSubmit={handleSubmit} className="text-slate-300 space-y-4">
        <div className="bg-slate-700 p-4 rounded-lg">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-white capitalize">{planInfo.plan.replace('-', '+')}</h3>
            <p className="text-2xl font-bold text-white">${planInfo.price}<span className="text-sm font-normal text-slate-400">/mo</span></p>
          </div>
          <p className="text-sm text-slate-400 capitalize">{planInfo.billingCycle} billing</p>
        </div>
        
        {isSoloPlan && (
          <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-center text-cyan-300 text-sm">
            Your <strong>7-day free trial</strong> will begin after signup. You can cancel anytime.
          </div>
        )}
        
        {/* Contact Info */}
        <div className="space-y-4">
            <h4 className="font-bold text-white">Contact Information</h4>
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-slate-300 mb-1">Full Name</label>
              <input type="text" id="name" value={name} onChange={e => setName(e.target.value)} required className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-1">Email Address</label>
              <input type="email" id="email" value={email} onChange={e => setEmail(e.target.value)} required className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
            </div>
            <div>
              <label htmlFor="company" className="block text-sm font-medium text-slate-300 mb-1">Company (Optional)</label>
              <input type="text" id="company" value={company} onChange={e => setCompany(e.target.value)} className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
            </div>
        </div>
        
        {/* Payment Info */}
        <div className="space-y-4 pt-4 border-t border-slate-700">
             <h4 className="font-bold text-white">Payment Details</h4>
             <p className="text-xs text-slate-400">Your card will not be charged until after the 7-day trial for Solo plans.</p>
             <div>
                <label htmlFor="cc-number" className="block text-sm font-medium text-slate-300 mb-1">Card Number</label>
                <div className="relative">
                    <input type="text" id="cc-number" value={ccNumber} onChange={e => setCcNumber(e.target.value)} required placeholder="•••• •••• •••• ••••" className="w-full px-3 py-2 pl-10 bg-slate-900 border border-slate-600 rounded-md text-white focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
                    <CreditCardIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400"/>
                </div>
             </div>
             <div className="flex space-x-4">
                <div className="flex-1">
                    <label htmlFor="cc-expiry" className="block text-sm font-medium text-slate-300 mb-1">Expiry</label>
                    <input type="text" id="cc-expiry" value={ccExpiry} onChange={e => setCcExpiry(e.target.value)} required placeholder="MM/YY" className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
                </div>
                 <div className="flex-1">
                    <label htmlFor="cc-cvc" className="block text-sm font-medium text-slate-300 mb-1">CVC</label>
                    <input type="text" id="cc-cvc" value={ccCvc} onChange={e => setCcCvc(e.target.value)} required placeholder="•••" className="w-full px-3 py-2 bg-slate-900 border border-slate-600 rounded-md text-white focus:ring-cyan-500 focus:border-cyan-500 outline-none" />
                </div>
             </div>
        </div>

        <div className="flex justify-end space-x-3 pt-4">
          <button type="button" onClick={onClose} className="px-4 py-2 bg-slate-600 hover:bg-slate-500 rounded-lg font-semibold">Cancel</button>
          <button type="submit" disabled={!isFormValid} className="px-4 py-2 bg-cyan-500 hover:bg-cyan-600 rounded-lg font-semibold disabled:bg-slate-600 disabled:cursor-not-allowed">
            {isSoloPlan ? 'Start 7-Day Trial' : 'Sign Up & Pay'}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default SignupModal;
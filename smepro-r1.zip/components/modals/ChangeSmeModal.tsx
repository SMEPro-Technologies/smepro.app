import React from 'react';
import { SmeConfig, UserProfile } from '../../types';
import Modal from './Modal';
import SmeSelector from '../SmeSelector';

interface ChangeSmeModalProps {
  userProfile: UserProfile;
  onClose: () => void;
  onConfirm: (config: SmeConfig) => void;
}

const ChangeSmeModal: React.FC<ChangeSmeModalProps> = ({ userProfile, onClose, onConfirm }) => {
  return (
    <Modal title="Switch SME" onClose={onClose}>
      <SmeSelector onStartChat={onConfirm} plan={userProfile.accountType} />
    </Modal>
  );
};

export default ChangeSmeModal;

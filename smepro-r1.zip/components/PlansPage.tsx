import React, { useState } from 'react';
import { SubscriptionPlan } from '../types';
import { CheckCircleIcon, VaultIcon, AnalyzeIcon, MarkdownIcon, CollaborationIcon, AddSmeIcon, SafetyIcon, SMEBuilderIcon, WorkshopModeIcon } from './icons';

interface PlansPageProps {
  onChoosePlan: (plan: SubscriptionPlan, billingCycle: 'monthly' | 'annual', price: number) => void;
}

const plansData = {
    base: [
        { id: 'solo' as SubscriptionPlan, name: 'SMEPro Solo', price: 25, description: 'For individuals, freelancers, and creators ready to turn ideas into outcomes.', features: ['50 AI Tasks/mo', '1 GB SMEVault Storage', 'Standard SMEAnalysis'] },
        { id: 'business' as SubscriptionPlan, name: 'SMEPro Business', price: 55, description: 'For teams and businesses needing collaborative intelligence and higher capacity.', features: ['250 AI Tasks/mo', '10 GB SMEVault Storage', 'Advanced SMEAnalysis'] }
    ],
    addons: [
        { id: 'solo-plus' as SubscriptionPlan, name: 'Solo Plus', price: 45, requires: 'Solo', description: 'Unlock collaborative tools and higher quotas for advanced individual projects.', features: ['Upgrades to 150 AI Tasks/mo', '5 GB SMEVault Storage', 'Enables Multi-SME Collab', 'Enables Workshop Mode'] },
        { id: 'pro-plus' as SubscriptionPlan, name: 'Business Advantage', price: 95, requires: 'Business', description: 'The ultimate package for teams requiring enterprise-grade AI collaboration and tools.', features: ['Upgrades to 500 AI Tasks/mo', '50 GB SMEVault Storage', 'Advanced SME Orchestration', 'Advanced Workshop Features'] },
        { id: 'super-plus' as SubscriptionPlan, name: 'Enterprise OEM', price: 0, requires: 'Any', description: 'Fully configurable solutions for large-scale deployment, custom integrations, and OEM licensing.', features: ['Unlimited Tiered Usage', 'Scalable TBs of Storage', 'Predictive Modeling', 'Dedicated Support'] }
    ],
    coreFeatures: [
        { icon: <VaultIcon className="w-6 h-6"/>, name: 'SMEVault', description: 'Your secure, centralized knowledge base. Store, tag, and retrieve key insights from all your sessions for future analysis and synthesis.' },
        { icon: <AnalyzeIcon className="w-6 h-6"/>, name: 'SMEAnalyzer', description: 'Leverage AI for deep contextual analysis. Synthesize new strategies and find hidden connections between your saved knowledge items.' },
        { icon: <SMEBuilderIcon className="w-6 h-6"/>, name: 'SMEBuilder', description: 'Move from analysis to creation. Use AI-augmented tools to draft plans, generate reports, and produce structured outputs from your insights.' },
        { icon: <CollaborationIcon className="w-6 h-6"/>, name: 'SMEWorkbench', description: 'A collaborative workspace to refine, tune, and configure Builder outputs into fully functional deliverables like apps, extensions, and guides.' },
        { icon: <AddSmeIcon className="w-6 h-6"/>, name: 'SMECollab', description: 'Engage with multiple AI experts in one session. The active SME detects context gaps and recommends adding other experts to the conversation.' },
        { icon: <SafetyIcon className="w-6 h-6"/>, name: 'SMESafeAI', description: 'A foundational commitment to safety. Our models are trained to avoid harmful outputs and protect your sensitive data.' },
    ]
};

const PlanCard: React.FC<{ plan: any, billingCycle: 'monthly' | 'annual', onChoose: () => void, isAddon?: boolean }> = ({ plan, billingCycle, onChoose, isAddon }) => {
    const displayPrice = billingCycle === 'annual' ? plan.price * 0.8 : plan.price;
    const isEnterprise = plan.price === 0;

    return (
        <div className={`flex flex-col p-6 rounded-lg border h-full ${isAddon ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-800 border-slate-700'}`}>
            <h3 className={`text-2xl font-bold ${isAddon ? 'text-cyan-400' : 'text-white'}`}>{plan.name}</h3>
            {isAddon && <p className="text-sm text-slate-400 mb-2">Requires {plan.requires} Plan</p>}
            <p className="text-slate-400 flex-grow">{plan.description}</p>
            {!isEnterprise && (
                <div className="my-6">
                    <span className="text-5xl font-extrabold text-white">${displayPrice.toFixed(2)}</span>
                    <span className="text-slate-400">/mo</span>
                </div>
            )}
            {isEnterprise && (
                 <div className="my-6">
                    <span className="text-3xl font-extrabold text-white">Custom Pricing</span>
                </div>
            )}
            <ul className="space-y-3 mb-8 text-slate-300">
                {plan.features.map((feature: string) => (
                    <li key={feature} className="flex items-start">
                        <CheckCircleIcon className="w-5 h-5 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{feature}</span>
                    </li>
                ))}
            </ul>
            <div className="mt-auto">
                 {isEnterprise ? (
                    <a href="mailto:sales@smepro.app" className="w-full block text-center py-3 font-semibold rounded-lg transition-colors bg-slate-700 hover:bg-slate-600 text-white">
                        Contact Sales
                    </a>
                ) : (
                    <button onClick={onChoose} className="w-full py-3 font-semibold rounded-lg transition-colors bg-cyan-500 hover:bg-cyan-600 text-white">
                        {isAddon ? 'Level Up' : 'Choose Plan'}
                    </button>
                )}
            </div>
        </div>
    );
};


const PlansPage: React.FC<PlansPageProps> = ({ onChoosePlan }) => {
    const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

    return (
    <div className="animate-fade-in container mx-auto px-4 sm:px-6 py-16 text-white">
        <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold">Find the Perfect Plan</h1>
            <p className="text-lg text-slate-400 mt-4 max-w-3xl mx-auto">Start with a core plan and add enhanced capabilities as you grow.</p>
        </div>

        <div className="flex justify-center items-center mb-10 space-x-4">
            <span className={`font-medium ${billingCycle === 'monthly' ? 'text-white' : 'text-slate-400'}`}>Monthly</span>
            <button onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')} className="relative inline-flex items-center h-6 rounded-full w-11 transition-colors bg-slate-700">
                <span className={`inline-block w-4 h-4 transform transition-transform bg-white rounded-full ${billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-1'}`}/>
            </button>
            <span className={`font-medium ${billingCycle === 'annual' ? 'text-white' : 'text-slate-400'}`}>Annual</span>
            <span className="text-sm bg-cyan-500/20 text-cyan-300 font-bold px-2 py-1 rounded-md hidden sm:inline-block">Save 20%</span>
        </div>
        
        {/* Plan Options */}
        <section>
            <h2 className="text-3xl font-bold text-center mb-8">Plan Options</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                {plansData.base.map(plan => (
                    <PlanCard 
                        key={plan.id}
                        plan={plan}
                        billingCycle={billingCycle}
                        onChoose={() => onChoosePlan(plan.id, billingCycle, billingCycle === 'annual' ? plan.price * 0.8 : plan.price)}
                    />
                ))}
            </div>
        </section>

        {/* Level up Addons */}
        <section className="mt-20">
            <h2 className="text-3xl font-bold text-center mb-8">Level Up Addons</h2>
             <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
                 {plansData.addons.map(plan => (
                    <PlanCard 
                        key={plan.id}
                        plan={plan}
                        billingCycle={billingCycle}
                        onChoose={() => onChoosePlan(plan.id, billingCycle, billingCycle === 'annual' ? plan.price * 0.8 : plan.price)}
                        isAddon
                    />
                ))}
            </div>
        </section>

        {/* Core Features */}
        <section className="mt-20 max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-12">All Plans Include Core Features</h2>
            <div className="grid md:grid-cols-2 gap-x-8 gap-y-10">
                {plansData.coreFeatures.map(feature => (
                    <div key={feature.name} className="flex items-start space-x-4">
                        <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-slate-800 text-cyan-400 rounded-lg">
                            {feature.icon}
                        </div>
                        <div>
                            <h3 className="text-lg font-bold">{feature.name}</h3>
                            <p className="text-slate-400">{feature.description}</p>
                        </div>
                    </div>
                ))}
            </div>
        </section>

    </div>
    );
};

export default PlansPage;
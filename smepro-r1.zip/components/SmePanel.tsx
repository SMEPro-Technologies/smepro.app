import React from 'react';
import { SuggestedSme, SmeConfig } from '../types';
import { UsersIcon, LoadingIcon, PlusIcon, CheckIcon, BrainCircuitIcon } from './icons';

interface SmePanelProps {
  activeSmes: SmeConfig[];
  suggestedSmes: SuggestedSme[];
  isLoading: boolean;
  onAddSme: (config: SmeConfig) => void;
}

const SmePanel: React.FC<SmePanelProps> = ({ activeSmes, suggestedSmes, isLoading, onAddSme }) => {

  return (
    <aside className="w-72 flex-shrink-0 bg-slate-800/50 border-l border-slate-700 flex flex-col">
      {/* Active SMEs */}
      <div className="p-4 border-b border-slate-700">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <BrainCircuitIcon className="w-5 h-5 text-cyan-400" />
          <span>Active SMEs</span>
        </h3>
        <p className="text-sm text-slate-400">Currently in your session.</p>
      </div>
      <div className="p-4 space-y-2">
        {activeSmes.map((sme, index) => (
            <div key={index} className="bg-slate-800 p-3 rounded-lg border border-slate-700">
              <h4 className="font-bold text-white">{sme.segment}</h4>
              <p className="text-xs text-cyan-400">{sme.subType}</p>
            </div>
        ))}
      </div>

      {/* Suggested SMEs */}
      <div className="p-4 border-t border-b border-slate-700">
        <h3 className="text-lg font-bold text-white flex items-center space-x-2">
          <UsersIcon className="w-5 h-5 text-cyan-400" />
          <span>Suggested SMEs</span>
        </h3>
        <p className="text-sm text-slate-400">Experts that could add value.</p>
      </div>
      <div className="flex-grow p-4 overflow-y-auto">
        {isLoading && (
          <div className="flex justify-center items-center h-full">
            <div className="text-center text-slate-400">
              <LoadingIcon className="w-6 h-6 mx-auto mb-2" />
              <p>Analyzing context...</p>
            </div>
          </div>
        )}
        {!isLoading && suggestedSmes.length === 0 && (
          <div className="text-center text-slate-500 pt-10 px-2">
            <p>No suggestions at this time. The list will update as you chat.</p>
          </div>
        )}
        {!isLoading && suggestedSmes.length > 0 && (
          <div className="space-y-3">
            {suggestedSmes.map((sme, index) => {
              const isAlreadyAdded = activeSmes.some(s => s.segment === sme.config.segment);
              return (
                <div key={index} className="bg-slate-800 p-3 rounded-lg border border-slate-700 animate-fade-in">
                  <div className="flex justify-between items-start">
                    <div className="pr-2">
                      <h4 className="font-bold text-white">{sme.config.segment}</h4>
                      <p className="text-xs text-cyan-400">{sme.config.subType}</p>
                    </div>
                    <button 
                      onClick={() => onAddSme(sme.config)}
                      title={isAlreadyAdded ? "SME already in session" : "Add SME to session"}
                      disabled={isAlreadyAdded}
                      className="p-1.5 bg-slate-700 hover:bg-cyan-500 rounded-md text-slate-300 hover:text-white transition-colors flex-shrink-0 disabled:bg-slate-600 disabled:cursor-not-allowed"
                    >
                      {isAlreadyAdded ? <CheckIcon className="w-4 h-4 text-green-400" /> : <PlusIcon className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-sm text-slate-400 mt-2 border-t border-slate-700 pt-2">{sme.reason}</p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </aside>
  );
};

export default SmePanel;
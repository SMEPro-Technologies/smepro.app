import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChatSession, UserProfile, ChatMessage, SuggestedSme, SmeConfig, WorkshopData, ResponseMode } from '../types';
import { geminiService } from '../services/geminiService';
import { collaborationService } from '../services/collaborationService';
import { UserIcon, ModelIcon, VaultIcon, DashboardIcon, SwitchIcon, SendIcon, LoadingIcon, ShareIcon, HistoryIcon, WorkshopModeIcon, InteractionModeIcon } from './icons';
import SmePanel from './SmePanel';
import Message from './Message';
import WorkshopSetup from './modals/WorkshopSetup';
import ResponseModeSelector from './ResponseModeSelector';
import ShareSessionModal from './modals/ShareSessionModal';

// Add marked to the window type
declare global {
    interface Window {
        marked: any;
        hljs: any;
    }
}

interface ChatWindowProps {
  session: ChatSession;
  userProfile: UserProfile;
  onSwitchSme: () => void;
  onShowVault: () => void;
  onShowDashboard: () => void;
  onProfileEdit: () => void;
  onSaveToVault: (message: ChatMessage) => void;
  onShowExplorer: () => void;
}

const ChatHeader: React.FC<Omit<ChatWindowProps, 'session' | 'userProfile' | 'onSaveToVault'> & { session: ChatSession, onShare: () => void, onOpenWorkshop: () => void, userProfile: UserProfile, isActionMode: boolean, onToggleActionMode: () => void }> = ({ onSwitchSme, onShowVault, onShowDashboard, onProfileEdit, session, onShare, onShowExplorer, onOpenWorkshop, isActionMode, onToggleActionMode }) => {
    const primarySme = session.smeConfigs[0];
    const headerTitle = session.smeConfigs.length > 1 
        ? `${session.smeConfigs[0].segment} & ${session.smeConfigs.length - 1} other${session.smeConfigs.length - 1 > 1 ? 's' : ''}`
        : session.smeConfigs[0].segment;
    
    const popoverTitle = session.smeConfigs.map(c => c.segment).join(' + ');

    return (
    <div className="flex-shrink-0 p-4 bg-slate-800/80 backdrop-blur-sm border-b border-slate-700 flex justify-between items-center" data-tour-id="chat-header">
        <div className="text-white group relative">
            <h2 className="font-bold text-lg truncate cursor-pointer" title={popoverTitle}>{headerTitle}</h2>
            <p className="text-sm text-slate-400 truncate">{primarySme.industry} / {primarySme.subType}</p>
            <div className="absolute top-full mt-2 w-72 bg-slate-900 border border-slate-700 text-white text-sm rounded-lg p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none shadow-lg z-20">
              <h4 className="font-bold text-base border-b border-slate-700 pb-2 mb-2">Active SMEs</h4>
              <ul className="space-y-1">
                  {session.smeConfigs.map((sme, i) => <li key={i} className="font-semibold text-slate-300">{sme.segment}</li>)}
              </ul>
              <div className="absolute left-4 -top-1.5 w-3 h-3 bg-slate-900 border-t border-l border-slate-700 transform rotate-45"></div>
            </div>
        </div>
        <div className="flex items-center space-x-1 sm:space-x-2">
            <button onClick={onOpenWorkshop} title="Workshop Mode" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"><WorkshopModeIcon className="w-5 h-5"/></button>
            <button onClick={onShare} title="Share Session" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"><ShareIcon className="w-5 h-5"/></button>
            <button onClick={onShowExplorer} title="Session History" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"><HistoryIcon className="w-5 h-5"/></button>
            <button onClick={onShowVault} title="Open Vault" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors" data-tour-id="chat-header-vault"><VaultIcon className="w-5 h-5"/></button>
            <button 
              onClick={onToggleActionMode} 
              title="Toggle Interactive Mode" 
              className={`p-2 rounded-full transition-colors ${isActionMode ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400 hover:text-white hover:bg-slate-700'}`}
            >
              <InteractionModeIcon className="w-5 h-5"/>
            </button>
            <button onClick={() => onShowDashboard()} title="Dashboard" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"><DashboardIcon className="w-5 h-5"/></button>
            <button onClick={onSwitchSme} title="Switch SME" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"><SwitchIcon className="w-5 h-5"/></button>
            <button onClick={onProfileEdit} title="Edit Profile" className="p-2 rounded-full hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"><UserIcon className="w-5 h-5"/></button>
        </div>
    </div>
)};

const ChatWindow: React.FC<ChatWindowProps> = (props) => {
  const { session, userProfile, onSaveToVault } = props;
  const [currentSession, setCurrentSession] = useState(session);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [suggestedSmes, setSuggestedSmes] = useState<SuggestedSme[]>([]);
  const [isSuggestingSmes, setIsSuggestingSmes] = useState(false);
  const [isWorkshopModalOpen, setIsWorkshopModalOpen] = useState(false);
  const [isGlobalActionMode, setIsGlobalActionMode] = useState(false);
  const [responseMode, setResponseMode] = useState<ResponseMode>('default');
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  
  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
        textarea.style.height = 'auto'; // Reset height
        const scrollHeight = textarea.scrollHeight;
        const maxHeight = 200; // 200px max height
        textarea.style.height = `${Math.min(scrollHeight, maxHeight)}px`;
        if (scrollHeight > maxHeight) {
            textarea.style.overflowY = 'auto';
        } else {
            textarea.style.overflowY = 'hidden';
        }
    }
  }, [input]);

  // Real-time collaboration listener
  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'smeProSessions' && event.newValue) {
        const updatedSessions = JSON.parse(event.newValue);
        const updatedSessionData = updatedSessions[session.sessionId];
        if (updatedSessionData && JSON.stringify(updatedSessionData.messages) !== JSON.stringify(currentSession.messages)) {
          setCurrentSession(updatedSessionData);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, [session.sessionId, currentSession.messages]);


  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentSession.messages]);
  
  const updateSuggestions = useCallback(async (history: ChatMessage[], configs: SmeConfig[]) => {
      if (session.accountType.startsWith('business') || session.accountType.endsWith('plus')) {
        setIsSuggestingSmes(true);
        const suggestions = await geminiService.suggestRelatedSmes(configs, history);
        setSuggestedSmes(suggestions);
        setIsSuggestingSmes(false);
      }
  }, [session.accountType]);

  // Fetch initial suggestions on mount
  useEffect(() => {
      updateSuggestions(currentSession.messages, currentSession.smeConfigs);
  }, []); // Only on initial mount

  const handleAddSme = async (newSmeConfig: SmeConfig) => {
    if (currentSession.smeConfigs.some(s => s.segment === newSmeConfig.segment)) return;

    setIsLoading(true);

    const introduction = await geminiService.generateSmeIntroduction(newSmeConfig, currentSession.messages);
    
    const modelMessage: ChatMessage = {
      role: 'model',
      content: introduction,
      timestamp: new Date().toISOString(),
      senderName: `${newSmeConfig.segment} SME`,
    };

    const updatedSession: ChatSession = {
      ...currentSession,
      smeConfigs: [...currentSession.smeConfigs, newSmeConfig],
      participants: [...currentSession.participants, { name: newSmeConfig.segment, isSme: true }],
      messages: [...currentSession.messages, modelMessage],
    };
    
    setCurrentSession(updatedSession);
    await collaborationService.saveSession(updatedSession);

    setIsLoading(false);
    updateSuggestions(updatedSession.messages, updatedSession.smeConfigs);
  };

  const handleGetDeeperInsight = async (selectedText: string, contextMessage: ChatMessage) => {
    setIsLoading(true);

    const insightResponse = await geminiService.getDeeperInsight(selectedText, contextMessage.content);
    
    const modelMessage: ChatMessage = {
      role: 'model',
      content: `**Insight on "${selectedText}":**\n\n${insightResponse}`,
      timestamp: new Date().toISOString(),
    };
    
    const finalSession = { ...currentSession, messages: [...currentSession.messages, modelMessage] };
    setCurrentSession(finalSession);
    setIsLoading(false);
    await collaborationService.saveSession(finalSession);
    updateSuggestions(finalSession.messages, finalSession.smeConfigs);
  };
  
  const handleStartWorkshop = async (workshopData: WorkshopData) => {
    const systemMessageContent = `
**WORKSHOP MODE ACTIVATED**

A structured collaborative session has been initiated with the following parameters:

- **Objective:** ${workshopData.objective}
- **Agenda:**
${workshopData.agenda.split('\n').map(item => `  - ${item}`).join('\n')}
- **Backstory:** ${workshopData.backstory}
- **Use Cases:** ${workshopData.useCases || 'Not specified'}

All participating SMEs will now align their expertise to achieve the stated objective.
    `.trim();

    const systemMessage: ChatMessage = {
      role: 'system',
      content: systemMessageContent,
      timestamp: new Date().toISOString(),
    };
    
    let updatedSession = { ...currentSession, messages: [...currentSession.messages, systemMessage] };

    if (workshopData.attendees && workshopData.attendees.length > 0) {
      const newSmes = workshopData.attendees.filter(
        attendee => !currentSession.smeConfigs.some(existing => existing.segment === attendee.segment)
      );

      if (newSmes.length > 0) {
        setIsLoading(true);

        const introductions = await Promise.all(
          newSmes.map(sme => geminiService.generateSmeIntroduction(sme, updatedSession.messages))
        );

        const introMessages: ChatMessage[] = introductions.map((intro, index) => ({
          role: 'model',
          content: intro,
          timestamp: new Date().toISOString(),
          senderName: `${newSmes[index].segment} SME`
        }));
        
        updatedSession = {
          ...updatedSession,
          smeConfigs: [...updatedSession.smeConfigs, ...newSmes],
          participants: [...updatedSession.participants, ...newSmes.map(sme => ({ name: sme.segment, isSme: true }))],
          messages: [...updatedSession.messages, ...introMessages],
        };

        setIsLoading(false);
      }
    }

    const finalModelMessage: ChatMessage = {
        role: 'model',
        content: "Workshop Mode is now active. All systems are aligned to your objectives. Let's begin.",
        timestamp: new Date().toISOString()
    };
    updatedSession.messages.push(finalModelMessage);

    setCurrentSession(updatedSession);
    await collaborationService.saveSession(updatedSession);
    setIsWorkshopModalOpen(false);
    updateSuggestions(updatedSession.messages, updatedSession.smeConfigs);
  };

  const handleToggleActionMode = () => {
    setIsGlobalActionMode(prev => !prev);
  };


  const handleSubmit = useCallback(async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;
    
    const responseModeText = responseMode.replace('-', ' ');
    const augmentedInput = responseMode === 'default' 
      ? input.trim() 
      : `[RESPONSE STYLE: ${responseModeText}] ${input.trim()}`;

    const userMessage: ChatMessage = {
      role: 'user',
      content: augmentedInput,
      timestamp: new Date().toISOString(),
      senderName: userProfile.name
    };
    
    const updatedMessages = [...currentSession.messages, userMessage];
    const sessionWithUserMessage = { ...currentSession, messages: updatedMessages };
    setCurrentSession(sessionWithUserMessage);
    setInput('');
    setIsLoading(true);
    setSuggestedSmes([]);
    
    await collaborationService.saveSession(sessionWithUserMessage);

    const responseContent = await geminiService.generateChatResponse(updatedMessages, currentSession.smeConfigs, currentSession.accountType);

    const modelMessage: ChatMessage = {
      role: 'model',
      content: responseContent,
      timestamp: new Date().toISOString(),
    };
    
    const finalSession = { ...sessionWithUserMessage, messages: [...updatedMessages, modelMessage] };
    setCurrentSession(finalSession);
    setIsLoading(false);

    await collaborationService.saveSession(finalSession);
    
    updateSuggestions(finalSession.messages, finalSession.smeConfigs);
  }, [input, isLoading, currentSession, userProfile.name, updateSuggestions, responseMode]);

  return (
    <div className="flex flex-col h-full bg-slate-900 text-slate-300">
      <ChatHeader 
        {...props} 
        session={currentSession} 
        onShare={() => setIsShareModalOpen(true)} 
        onOpenWorkshop={() => setIsWorkshopModalOpen(true)}
        isActionMode={isGlobalActionMode}
        onToggleActionMode={handleToggleActionMode}
      />
      <div className="flex flex-grow overflow-hidden">
        <div className="flex-grow flex flex-col">
            <div className="flex-grow p-4 overflow-y-auto">
                <div className="max-w-3xl mx-auto">
                    {currentSession.messages.map((msg, index) => (
                        <Message 
                          key={index} 
                          message={msg} 
                          currentUser={userProfile} 
                          onSave={onSaveToVault}
                          onGetInsight={handleGetDeeperInsight}
                          isActionMode={isGlobalActionMode}
                        />
                    ))}
                    {isLoading && (
                        <div className="flex items-start space-x-4 py-4 animate-fade-in">
                            <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-cyan-500">
                                <LoadingIcon className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-grow text-white pt-1">Thinking...</div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
            </div>
            <div className="flex-shrink-0 p-4 bg-slate-800 border-t border-slate-700" data-tour-id="chat-input">
                <div className="max-w-3xl mx-auto">
                    <form onSubmit={handleSubmit} className="relative">
                        <textarea
                            ref={textareaRef}
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && !e.shiftKey) {
                                    e.preventDefault();
                                    handleSubmit();
                                }
                            }}
                            placeholder="Ask your SME a question..."
                            className="w-full p-4 pl-14 pr-14 bg-slate-700 border border-slate-600 rounded-lg text-white resize-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 outline-none"
                            rows={2}
                            disabled={isLoading}
                        />
                        <ResponseModeSelector
                            selectedMode={responseMode}
                            onModeChange={setResponseMode}
                        />
                        <button type="submit" disabled={isLoading || !input.trim()} className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-cyan-500 text-white hover:bg-cyan-600 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors">
                            <SendIcon className="w-5 h-5"/>
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <SmePanel
            activeSmes={currentSession.smeConfigs}
            suggestedSmes={suggestedSmes} 
            isLoading={isSuggestingSmes}
            onAddSme={handleAddSme}
        />
      </div>
      {isWorkshopModalOpen && currentSession.smeConfigs[0] && (
        <WorkshopSetup 
          onClose={() => setIsWorkshopModalOpen(false)}
          onStart={handleStartWorkshop}
          primarySmeConfig={currentSession.smeConfigs[0]}
        />
      )}
      {isShareModalOpen && (
        <ShareSessionModal
          sessionId={session.sessionId}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}
    </div>
  );
};

export default ChatWindow;
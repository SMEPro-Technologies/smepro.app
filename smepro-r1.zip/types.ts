// FIX: Import React to provide types for JSX.IntrinsicElements.
import type * as React from 'react';

// FIX: Added a global declaration for JSX.IntrinsicElements to solve widespread component errors.
// This is a workaround for a presumed tsconfig.json or dependency issue.
declare global {
    namespace JSX {
        interface IntrinsicElements {
            'stripe-buy-button': React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement> & {
                buyButtonId?: string;
                publishableKey?: string;
              };
            [elemName: string]: any;
        }
    }
}

export type SubscriptionPlan = 'solo' | 'solo-plus' | 'business' | 'pro-plus' | 'super-plus';
export type MarketingPage = 'home' | 'features' | 'how-it-works' | 'plans' | 'safe-ai' | 'smepro-review';
export type CurrentView = MarketingPage | 'app';
export type ResponseMode = 'default' | 'quick-insight' | 'solution' | 'cited-facts' | 'legal' | 'overview' | 'synopsis';

export interface Quota {
  limit: number;
  used: number;
}

export interface UserProfile {
  name: string;
  email: string;
  company: string;
  accountType: SubscriptionPlan;
  billingCycle: 'monthly' | 'annual';
  quotas: {
    vaultStorage: Quota; // in GB
    analyzerActions: Quota; // monthly actions
    aiBandwidth: Quota; // abstract units
  };
}

export interface SmeConfig {
  industry: string;
  subType: string;
  segment: string;
}

export interface ChatMessage {
  role: 'user' | 'model' | 'system';
  content: string;
  timestamp: string;
  senderName?: string; // The user who sent the message
}

export interface ChatSession {
  sessionId: string;
  smeConfigs: SmeConfig[];
  messages: ChatMessage[];
  accountType: SubscriptionPlan;
  participants: { name: string; isSme?: boolean }[];
}

export interface VaultItem {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  createdAt: string;
  builderReady?: boolean;
}

export interface ApiConnector {
  id: string;
  provider: 'openai' | 'grok' | 'aws';
  apiKey: string; 
  lastSync: string | null;
}

export interface AdminUser {
  id: string;
  name: string;
  email: string;
  plan: SubscriptionPlan;
  signupDate: string;
  status: 'Active' | 'Trial' | 'Cancelled';
}

export interface SupportTicket {
  id: string;
  userEmail: string;
  subject: string;
  submittedAt: string;
  status: 'Open' | 'In Progress' | 'Closed';
}

export interface SuggestedSme {
  config: SmeConfig;
  reason: string;
}

export interface WorkshopData {
  objective: string;
  agenda: string;
  backstory: string;
  useCases: string;
  attendees?: SmeConfig[];
}

export interface AiPlatform {
  name: string;
  category: string;
  claimToFame: string;
}
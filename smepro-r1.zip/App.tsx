
import React, { useState, useEffect, useCallback } from 'react';
import { SmeConfig, UserProfile, ChatSession, ChatMessage } from './types';
import { SubscriptionPlan, CurrentView } from './types';
import { collaborationService } from './services/collaborationService';
import { backend } from './services/backend';
import { generateId } from './constants';
import Header from './components/Header';
import HomePage from './components/HomePage';
import FeaturesPage from './components/FeaturesPage';
import HowItWorksPage from './components/HowItWorksPage';
import PlansPage from './components/PlansPage';
import SmeSelector from './components/SmeSelector';
import ChatWindow from './components/ChatWindow';
import Vault from './components/Vault';
import Dashboard from './components/Dashboard';
import EditProfileModal from './components/modals/EditProfileModal';
import ChangeSmeModal from './components/modals/ChangeSmeModal';
import ManageCategoriesModal from './components/modals/ManageCategoriesModal';
import OnboardingTour from './components/OnboardingTour';
import SignupModal from './components/modals/SignupModal';
import SaveToVaultModal from './components/modals/SaveToVaultModal';
import SessionExplorer from './components/SessionExplorer';
import AdminLoginPage from './components/admin/AdminLoginPage';
import AdminDashboard from './components/admin/AdminDashboard';
import SafeAiPage from './components/SafeAiPage';
import HelpPage from './components/HelpPage';
import { QuestionMarkCircleIcon } from './components/icons';
import SmeProReviewPage from './components/SmeProReviewPage';


const LAST_SESSION_ID_KEY = 'smeProLastSessionId';
const ONBOARDING_COMPLETE_KEY = 'smeProOnboardingComplete';

const App: React.FC = () => {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [currentSession, setCurrentSession] = useState<ChatSession | null>(null);
  
  const [currentPage, setCurrentPage] = useState<CurrentView>('home');
  const [signupModalInfo, setSignupModalInfo] = useState<{ plan: SubscriptionPlan, billingCycle: 'monthly' | 'annual', price: number } | null>(null);
  
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isEditProfileModalOpen, setIsEditProfileModalOpen] = useState(false);
  const [isChangeSmeModalOpen, setIsChangeSmeModalOpen] = useState(false);
  const [isManageCategoriesModalOpen, setIsManageCategoriesModalOpen] = useState(false);
  const [isExplorerOpen, setIsExplorerOpen] = useState(false);
  const [isHelpPageOpen, setIsHelpPageOpen] = useState(false);
  
  const [vaultReloadKey, setVaultReloadKey] = useState(Date.now());
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [itemToSave, setItemToSave] = useState<ChatMessage | null>(null);
  
  const [showAdminView, setShowAdminView] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);


  useEffect(() => {
    backend.fetchUserProfile().then(profile => {
      if (profile) {
        setUserProfile(profile);
      }
      const onboardingComplete = localStorage.getItem(ONBOARDING_COMPLETE_KEY) === 'true';
      if (!onboardingComplete && !profile) {
        //setShowOnboarding(true); // Temporarily disable for easier debugging
      }
    });

    const handleHashChange = () => {
        if (window.location.hash === '#admin') {
            setShowAdminView(true);
        } else {
            setShowAdminView(false);
        }
    };
    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Check on initial load
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const loadSession = useCallback(async (profile: UserProfile, sessionId?: string) => {
    const lastSessionId = sessionId || localStorage.getItem(LAST_SESSION_ID_KEY);
    if (lastSessionId) {
      const session = await collaborationService.getSession(lastSessionId, undefined, undefined, profile);
      if (session) {
        setCurrentSession(session);
      } else {
        localStorage.removeItem(LAST_SESSION_ID_KEY);
      }
    }
  }, []);

  useEffect(() => {
    if (userProfile && currentPage === 'app' && !currentSession) {
      loadSession(userProfile);
    }
  }, [userProfile, currentPage, loadSession, currentSession]);

  const handleStartChat = async (smeConfig: SmeConfig) => {
    if (userProfile) {
      const newSessionId = generateId();
      const newSession = await collaborationService.getSession(newSessionId, smeConfig, userProfile.accountType, userProfile);
      setCurrentSession(newSession);
      localStorage.setItem(LAST_SESSION_ID_KEY, newSessionId);
    }
  };

  const handleSwitchSmeConfirm = async (smeConfig: SmeConfig) => {
    if (userProfile) {
        handleStartChat(smeConfig); // This creates a new session
        setIsChangeSmeModalOpen(false);
    }
  };

  const handleSignupConfirm = async (
    signupData: { name: string; email: string; company: string },
    planInfo: { plan: SubscriptionPlan; billingCycle: 'monthly' | 'annual' }
  ) => {
    const newProfile: Omit<UserProfile, 'quotas'> = {
      ...signupData,
      accountType: planInfo.plan,
      billingCycle: planInfo.billingCycle,
    };
    const savedProfile = await backend.saveUserProfile(newProfile);

    // CRITICAL: Clear any old session data before setting the new profile and navigating.
    // This ensures the user is taken to the SmeSelector.
    localStorage.removeItem(LAST_SESSION_ID_KEY);
    setCurrentSession(null);

    setUserProfile(savedProfile);
    setSignupModalInfo(null);
    setCurrentPage('app');
    
    const onboardingComplete = localStorage.getItem(ONBOARDING_COMPLETE_KEY) === 'true';
    if (!onboardingComplete) {
      // setShowOnboarding(true);
    }
  };

  const handleProfileSave = async (updatedProfile: UserProfile) => {
    const savedProfile = await backend.saveUserProfile(updatedProfile);
    setUserProfile(savedProfile);
    setIsEditProfileModalOpen(false);
    alert('Profile updated successfully!');
  };

  const handlePlanChoice = (plan: SubscriptionPlan, billingCycle: 'monthly' | 'annual', price: number) => {
    if (userProfile) {
      if (plan === userProfile.accountType) {
        alert("This is your current plan.");
        return;
      }
      if (confirm(`You are about to change your plan to ${plan}. Do you want to continue?`)) {
        // FIX: Reworked object creation to avoid confusing TypeScript's type inference with complex destructuring.
        const { quotas, ...profileToSave } = userProfile;
        const updatedProfile = { ...profileToSave, accountType: plan, billingCycle: billingCycle };
        backend.saveUserProfile(updatedProfile).then(savedProfileWithNewQuotas => {
            setUserProfile(savedProfileWithNewQuotas);
            alert(`Your plan has been updated to ${plan}!`);
            // Stay on the plans page for a better UX, don't navigate away.
        });
      }
    } else {
      setSignupModalInfo({ plan, billingCycle, price });
    }
  };
  
  const handleSaveToVault = (message: ChatMessage) => {
      setItemToSave(message);
  };
  
  const handleItemSaved = () => {
      setItemToSave(null);
      setVaultReloadKey(Date.now()); // Trigger vault refresh
      alert("Item saved to Vault!");
  };

  const handleSelectSession = (sessionId: string) => {
    if (userProfile) {
      loadSession(userProfile, sessionId);
      localStorage.setItem(LAST_SESSION_ID_KEY, sessionId);
      setIsExplorerOpen(false);
    }
  };
  
  const handleSaveTextToVault = (text: string) => {
    const message: ChatMessage = {
      role: 'user', // or model, depending on context. User seems safe.
      content: text,
      timestamp: new Date().toISOString()
    };
    setItemToSave(message);
  };

  const handleContinueInBuilder = async (analysisContent: string) => {
    if (!userProfile) return;

    // 1. Define a specific SME config for the Builder
    const builderSmeConfig: SmeConfig = {
      industry: 'Professional Services',
      subType: 'Management Consulting',
      segment: 'Executive Management', // Represents a "Solution Architect" or "Planner"
    };

    // 2. Create a new session with this SME
    const newSessionId = generateId();
    const newSession = await collaborationService.getSession(newSessionId, builderSmeConfig, userProfile.accountType, userProfile);
    
    if (newSession) {
      // 3. Add context messages to the new session
      const systemMessage: ChatMessage = {
        role: 'system',
        content: `**SMEBuilder Session Initiated.**\nThe following analysis has been loaded as context:\n\n---\n${analysisContent}\n---`,
        timestamp: new Date().toISOString(),
      };
      const modelIntroMessage: ChatMessage = {
        role: 'model',
        content: "I have reviewed the provided analysis. Let's begin building a tangible plan from these insights. What is our first step?",
        timestamp: new Date().toISOString(),
        senderName: `${builderSmeConfig.segment} SME`,
      };

      newSession.messages.push(systemMessage, modelIntroMessage);
      
      // 4. Set the new session as current and close the vault
      await collaborationService.saveSession(newSession);
      setCurrentSession(newSession);
      localStorage.setItem(LAST_SESSION_ID_KEY, newSessionId);
      setIsVaultOpen(false);
      setCurrentPage('app');
    }
  };

  const handleNavigation = (page: CurrentView) => {
    setCurrentPage(page);
    if(isDashboardOpen) setIsDashboardOpen(false);
    if(isEditProfileModalOpen) setIsEditProfileModalOpen(false);

  };

  const handleGetStarted = () => {
    if (userProfile) {
      setCurrentPage('app');
    } else {
      setCurrentPage('plans');
    }
  };

  const renderContent = () => {
    if (currentPage === 'app') {
      if (!userProfile) {
        // Fallback for logged-out user trying to access app
        return <HomePage onGetStarted={handleGetStarted} />;
      }
      return (
        <main className="h-screen flex flex-col">
          {currentSession ? (
            <ChatWindow 
              session={currentSession} 
              userProfile={userProfile}
              onSwitchSme={() => setIsChangeSmeModalOpen(true)}
              onShowVault={() => setIsVaultOpen(true)}
              onShowDashboard={() => setIsDashboardOpen(true)}
              onProfileEdit={() => setIsEditProfileModalOpen(true)}
              onSaveToVault={handleSaveToVault}
              onShowExplorer={() => setIsExplorerOpen(true)}
            />
          ) : (
            <SmeSelector onStartChat={handleStartChat} plan={userProfile.accountType} />
          )}
          
          {isVaultOpen && <div className="absolute inset-0 z-30"><Vault userProfile={userProfile} onClose={() => setIsVaultOpen(false)} onManageCategories={() => setIsManageCategoriesModalOpen(true)} onSaveText={handleSaveTextToVault} onContinueInBuilder={handleContinueInBuilder} key={vaultReloadKey} /></div>}
          {isDashboardOpen && <div className="absolute inset-0 z-30"><Dashboard userProfile={userProfile} onClose={() => setIsDashboardOpen(false)} onNavigate={handleNavigation} /></div>}

          {isEditProfileModalOpen && userProfile && <EditProfileModal currentUserProfile={userProfile} onSave={handleProfileSave} onClose={() => setIsEditProfileModalOpen(false)} onSyncComplete={() => alert('Connectors synced!')} onNavigate={handleNavigation} />}
          {isChangeSmeModalOpen && userProfile && <ChangeSmeModal userProfile={userProfile} onClose={() => setIsChangeSmeModalOpen(false)} onConfirm={handleSwitchSmeConfirm} />}
          {isManageCategoriesModalOpen && <ManageCategoriesModal onClose={() => setIsManageCategoriesModalOpen(false)} />}
          {isExplorerOpen && currentSession && <SessionExplorer currentSessionId={currentSession.sessionId} onSelectSession={handleSelectSession} onClose={() => setIsExplorerOpen(false)} />}
          {itemToSave && <SaveToVaultModal message={itemToSave} onClose={() => setItemToSave(null)} onSave={handleItemSaved} />}
          {isHelpPageOpen && <div className="absolute inset-0 z-50"><HelpPage onClose={() => setIsHelpPageOpen(false)} /></div>}
          
          <button 
              onClick={() => setIsHelpPageOpen(true)}
              className="fixed bottom-6 right-6 z-40 p-3 bg-cyan-500 text-white rounded-full shadow-lg hover:bg-cyan-600 transition-transform hover:scale-110"
              title="Help & Documentation"
          >
              <QuestionMarkCircleIcon className="w-8 h-8"/>
          </button>
        </main>
      );
    }
    
    switch(currentPage) {
      case 'home': return <HomePage onGetStarted={handleGetStarted} />;
      case 'features': return <FeaturesPage onGetStarted={handleGetStarted} />;
      case 'how-it-works': return <HowItWorksPage onGetStarted={handleGetStarted} />;
      case 'plans': return <PlansPage onChoosePlan={handlePlanChoice} />;
      case 'safe-ai': return <SafeAiPage onGetStarted={handleGetStarted} />;
      case 'smepro-review': return <SmeProReviewPage onGetStarted={handleGetStarted} />;
      default: return <HomePage onGetStarted={handleGetStarted} />;
    }
  };

  if (showAdminView) {
    if (!isAdminLoggedIn) {
        return <AdminLoginPage onLogin={setIsAdminLoggedIn} />;
    }
    return <AdminDashboard onLogout={() => { setIsAdminLoggedIn(false); window.location.hash = ''; }} />;
  }

  const showHeader = !!userProfile || currentPage !== 'home';

  return (
    <div className="min-h-screen bg-slate-900 font-sans">
      {showHeader && (
        <Header 
          isLoggedIn={!!userProfile}
          onNavigate={handleNavigation}
          currentPage={currentPage}
        />
      )}
      {renderContent()}

      {signupModalInfo && <SignupModal planInfo={signupModalInfo} onConfirm={handleSignupConfirm} onClose={() => setSignupModalInfo(null)} />}
      
      {showOnboarding && <OnboardingTour onFinish={() => { setShowOnboarding(false); localStorage.setItem(ONBOARDING_COMPLETE_KEY, 'true'); }} />}
    </div>
  );
};

export default App;

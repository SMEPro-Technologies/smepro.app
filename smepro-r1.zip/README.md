# 📘 SMEPro Frontend
A modern React + Vite single-page application (SPA) for SMEPro Intelligence AI, powered by the Google Gemini API. This frontend provides the Vault, Chat, Dashboard, and AI Safety interfaces for smepro.app, connecting to a backend deployed on Google Cloud Run.

## ✨ Features
- **Vault**: Save, search, and analyze curated knowledge items.
- **ChatWindow**: Engage in contextual, collaborative SME sessions powered by Gemini.
- **SAFE AI**: An interactive page demonstrating SMEPro's commitment to safety and responsible AI.
- **SMEPro Review**: A competitive analysis tool to compare SMEPro against other top AI platforms.
- **Workshop Mode**: A structured, collaborative workspace where a team of AI experts can co-create and refine outputs.
- **Systematic & Dynamic Prompts**: Receive AI-generated next steps to guide your workflow.

## 🚀 Tech Stack
- **React 18 + Vite 5**: For fast development and efficient build tooling.
- **TypeScript**: Ensures type safety and enhances code maintainability.
- **TailwindCSS**: A utility-first CSS framework for rapid UI development.
- **Google GenAI SDK (@google/genai)**: Powers the AI analysis and synthesis capabilities.
- **Marked + Highlight.js**: Renders rich markdown content.

## 📂 Project Structure
```text
src/
├── components/   # UI components (Vault, ChatWindow, Dashboard, Modals, Pages)
├── services/     # API services (backend.ts, geminiService.ts, etc.)
├── types.ts      # Shared type definitions
├── constants.ts  # Application constants
├── App.tsx       # Root application component
└── index.tsx     # Entry point
public/
└── schemas/      # JSON configs (vault_categories.json, business_categories.json, etc.)
scripts/
├── deploy.sh     # Deployment script for Google Cloud Run
└── init_db.sql   # PostgreSQL database initialization script
config/
└── nginx.conf    # Nginx configuration for Docker deployment
```

## ⚙️ Getting Started

### Prerequisites
- Node.js (v18 or later recommended)
- npm or yarn

### Installation
1.  **Clone the repository:**
    ```bash
    git clone <your-repo-url>
    cd <your-repo-name>
    ```
2.  **Install dependencies:**
    ```bash
    npm install
    ```

### Running Locally
1.  **Create a `.env` file** in the project root and add your Google GenAI API key:
    ```env
    VITE_API_KEY=your-google-genai-key
    ```
2.  **Start the development server:**
    ```bash
    npm run dev
    ```
The application will be available at `http://localhost:5173`. API calls to `/api` are proxied by `vite.config.ts`.

## 🐳 Building for Production with Docker
To create a production-ready Docker image, run:
```bash
docker build -t smepro-frontend --build-arg VITE_API_KEY="your-google-genai-key" .
```
Then you can run the container:
```bash
docker run -p 8080:80 smepro-frontend
```
The application will be available at `http://localhost:8080`.

## 🌐 Deployment
This project is configured for deployment to **Google Cloud Run**.

1.  **Build and deploy using the script:**
    The `scripts/deploy.sh` script automates the process. First, make it executable:
    ```bash
    chmod +x scripts/deploy.sh
    ```
    Then, update the configuration variables inside the script (`PROJECT_ID`, `VITE_API_KEY`) and run it:
    ```bash
    ./scripts/deploy.sh
    ```
2.  **Database Setup:**
    The `scripts/init_db.sql` file contains the necessary SQL to set up your customer database in a PostgreSQL instance (like Google Cloud SQL). Run this file against your database to create the required tables for plans, profiles, and payments.
